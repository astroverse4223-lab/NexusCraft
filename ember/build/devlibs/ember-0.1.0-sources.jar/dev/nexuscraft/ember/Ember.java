package dev.nexuscraft.ember;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Ember — a lantern keeper that follows you and burns the dark back.
 *
 * Deliberately not part of Hollow. Hollow is a face with no body that grows
 * less friendly the longer you keep it; this is a body with no face that simply
 * helps, and the two would undercut each other sharing a jar.
 */
public class Ember implements ModInitializer {

    public static final String MOD_ID = "ember";

    public static final Logger LOG = LoggerFactory.getLogger("Ember");

    /** One voice for the server, holding the short conversation history. */
    private static final Voice VOICE = new Voice();

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    public static final RegistryKey<EntityType<?>> EMBER_KEY =
            RegistryKey.of(RegistryKeys.ENTITY_TYPE, id("ember"));

    public static final EntityType<EmberEntity> EMBER = Registry.register(
            Registries.ENTITY_TYPE,
            EMBER_KEY,
            EntityType.Builder.create(EmberEntity::new, SpawnGroup.MISC)
                    .dimensions(0.5f, 0.6f)
                    .makeFireImmune()
                    .build(EMBER_KEY));

    public static final RegistryKey<Item> LANTERN_KEY =
            RegistryKey.of(RegistryKeys.ITEM, id("ember_lantern"));

    public static final Item EMBER_LANTERN = Registry.register(
            Registries.ITEM,
            LANTERN_KEY,
            new EmberLanternItem(new Item.Settings()
                    .registryKey(LANTERN_KEY)
                    .maxCount(1)));

    @Override
    public void onInitialize() {
        FabricDefaultAttributeRegistry.register(EMBER, EmberEntity.createEmberAttributes());

        /*
         * In the creative menu beside the other tools.
         *
         * A registered item that belongs to no group exists and is completely
         * unreachable: it will not appear in creative, and the only way to hold
         * one is to already know the recipe. The first build shipped that way,
         * and the mod looked broken because nothing could be found.
         */
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS)
                .register(entries -> entries.add(EMBER_LANTERN));

        EmberCommand.register();

        /*
         * Ember answers when its own owner speaks near it.
         *
         * Gated on the owner rather than on everyone: on a server, a lantern
         * that replies to every line of chat is noise, and four of them
         * replying at once is unusable.
         */
        /*
         * Load the model before anyone asks it anything.
         *
         * Without this the first question of a session pays the whole model
         * load and times out, which reads as the mod being broken rather than
         * as Ollama being cold.
         */
        ServerLifecycleEvents.SERVER_STARTED.register(server -> Warmth.warm());
        ServerTickEvents.END_SERVER_TICK.register(server -> Warmth.tick());

        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> {
            String text = message.getContent().getString().trim();
            if (text.isEmpty() || text.startsWith("/")) return;

            List<EmberEntity> nearby = sender.getEntityWorld().getEntitiesByClass(
                    EmberEntity.class,
                    sender.getBoundingBox().expand(24.0),
                    candidate -> sender.getUuid().equals(candidate.getOwnerId()));

            if (nearby.isEmpty()) return;
            VOICE.hear(sender.getEntityWorld().getServer(), sender, nearby.get(0), text);
        });
    }
}
