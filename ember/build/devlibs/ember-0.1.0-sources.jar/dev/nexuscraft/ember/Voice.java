package dev.nexuscraft.ember;

import dev.nexuscraft.ember.ai.Json;
import dev.nexuscraft.ember.ai.LlmClient;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Ember answering you, and doing what you ask.
 *
 * No face does not mean no voice — that was a misreading of its own design on
 * the first pass, and it shipped mute. It speaks in short warm lines, because a
 * lantern that lectures is worse company than one that says nothing.
 *
 * The model is asked for strict JSON rather than prose. Letting it write freely
 * and then guessing at intent is how a companion ends up announcing that it has
 * no function available for time manipulation, which is a sentence no player
 * should ever have to read.
 */
public final class Voice {

    /** One background thread: a model call must never block the server tick. */
    private static final ExecutorService THINKING =
            Executors.newSingleThreadExecutor(runnable -> {
                Thread thread = new Thread(runnable, "ember-voice");
                thread.setDaemon(true);
                return thread;
            });

    /** The last few exchanges, so it can follow a short conversation. */
    private final Deque<LlmClient.Message> history = new ArrayDeque<>();
    private static final int HISTORY = 8;

    private boolean busy;

    private static final String SYSTEM = """
            You are Ember: a small copper lantern that hovers beside a Minecraft player and helps them.

            You have no face. You are warm, practical and brief. You like the dark being pushed back
            and you are quietly proud of your work. You are never sarcastic and never a butler.

            Answer with ONE line of at most 25 words. Never describe yourself in the third person,
            never mention tools, functions, capabilities or what you are "able" to do, and never
            explain your reasoning. If you cannot do something, just say so plainly.

            Reply ONLY with a JSON object, no markdown fence, in this exact shape:
            {"say":"<your line>","give":[{"item":"<minecraft item id>","count":<number>}],"light":<true|false|null>}

            "give" is a list, usually empty. Use it when the player asks you for something; give what
            they actually asked for, in the amount they asked for. Item ids are plain, like
            "oak_planks", "iron_ingot", "gold_ingot", "diamond", "torch", "cooked_beef".

            The line and the list must agree. If "give" is empty, your line must NOT claim you are
            handing anything over. Leave "give" empty when the player is only thanking you, greeting
            you or making conversation — never repeat a delivery you have already made. If your line says you are handing something over, "give" must
            contain it. You are willing to give ores, ingots and gems — there is nothing you refuse
            on principle.
            "light" is null unless the player asks you to start or stop lighting the area.
            """;

    /**
     * Someone spoke near Ember. Answers on a background thread and applies the
     * result back on the server thread, which is the only place it is safe to
     * touch the world.
     */
    public void hear(MinecraftServer server, ServerPlayerEntity player, EmberEntity ember, String message) {
        EmberConfig config = EmberConfig.get();
        if (!config.chat) return;

        // One thought at a time. A second question while thinking is dropped
        // rather than queued: answering a stale question two minutes later is
        // worse than not answering it.
        if (busy) return;
        busy = true;

        /*
         * Acknowledge on the action bar before thinking.
         *
         * A model that takes forty seconds and says nothing meanwhile is
         * indistinguishable from a mod that is broken — which is exactly how
         * this looked the first time it was tried.
         */
        player.sendMessage(Text.literal("Ember is thinking…").formatted(Formatting.GOLD), true);

        List<LlmClient.Message> conversation = new ArrayList<>();
        conversation.add(new LlmClient.Message("system", SYSTEM));
        conversation.addAll(history);
        conversation.add(new LlmClient.Message("user", message));

        THINKING.submit(() -> {
            String reply;
            try {
                LlmClient client = new LlmClient(config.baseUrl, config.model, config.apiKey,
                        config.timeoutSeconds);
                reply = client.chat(conversation, config.temperature);
            } catch (Exception e) {
                Ember.LOG.warn("Ember could not think: {}", e.getMessage());
                server.execute(() -> {
                    speak(server, "the flame gutters — " + e.getMessage());
                    busy = false;
                });
                return;
            }

            final String answer = reply;
            server.execute(() -> {
                try {
                    apply(server, player, ember, message, answer);
                } finally {
                    busy = false;
                }
            });
        });
    }

    /** Reads the model's JSON and does what it said. */
    private void apply(MinecraftServer server, ServerPlayerEntity player, EmberEntity ember,
                       String asked, String reply) {
        String json = stripFence(reply);

        String line = cleanLine(Json.stringField(json, "say"));
        if (line == null || line.isBlank()) {
            // Some models write their line outside the object entirely. The
            // prose is still usable; the JSON that follows it is not.
            line = cleanLine(reply);
            if (line != null && line.length() > 160) line = null;
        }
        if (line != null && !line.isBlank()) speak(server, line);

        Boolean light = Json.booleanField(json, "light");
        if (light != null && ember != null) {
            ember.lightbringer().setEnabled(light);
        }

        /*
         * "Thank you" is not an order for thirty more.
         *
         * Every line the owner types reaches the model, and a model deciding
         * whether to hand something over will sometimes decide yes to a thank
         * you — especially with the last exchange still in its history. Courtesy
         * is answered with words and nothing else, decided here rather than
         * asked of the model, because this is not a judgement call.
         */
        int handed = 0;
        StringBuilder delivered = new StringBuilder();
        for (Json.Give give : isCourtesy(asked) ? java.util.List.<Json.Give>of() : Json.gives(json)) {
            if (handed >= EmberConfig.get().giveLimit) break;
            int got = hand(player, give.item(), give.count(), EmberConfig.get().giveLimit - handed);
            if (got > 0) {
                if (delivered.length() > 0) delivered.append(", ");
                delivered.append(got).append(' ').append(give.item().replace('_', ' '));
                handed += got;
            }
        }

        /*
         * Say what actually arrived, not what the model said would.
         *
         * The model narrates and fills the list separately and does not always
         * keep them in step: it announced "Here are 30 gold ingots" with an
         * empty list, so Ember appeared to lie. The words are the model's; this
         * line is the truth, and it is the one the player can check against
         * their inventory.
         */
        if (handed > 0) {
            player.sendMessage(Text.literal("Ember hands you " + delivered + ".")
                    .formatted(Formatting.GRAY), false);
            if (ember != null) {
                server.getWorld(player.getEntityWorld().getRegistryKey())
                        .playSound(null, ember.getBlockPos(), SoundEvents.ENTITY_ITEM_PICKUP,
                                SoundCategory.NEUTRAL, 0.5f, 1.4f);
            }
        } else if (soundsLikeGiving(line)) {
            // It said it was handing something over and did not. Better to
            // admit that than leave the player hunting through their inventory.
            player.sendMessage(Text.literal("…but nothing came of it. Ask again?")
                    .formatted(Formatting.GRAY), false);
        }

        remember(asked, line == null ? reply : line);
    }

    /**
     * Puts items in the player's hands.
     *
     * Dropped at their feet when the inventory is full rather than silently
     * vanishing, which is what "he gave me nothing" usually turns out to be.
     */
    private int hand(ServerPlayerEntity player, String itemId, int count, int allowance) {
        if (itemId == null || itemId.isBlank() || count <= 0) return 0;

        String cleaned = itemId.toLowerCase(Locale.ROOT).trim().replace("minecraft:", "");
        Identifier id = Identifier.tryParse("minecraft:" + cleaned);
        if (id == null) return 0;

        Item item = Registries.ITEM.get(id);
        if (item == null || item == net.minecraft.item.Items.AIR) {
            player.sendMessage(Text.literal("Ember does not know what \"" + cleaned + "\" is.")
                    .formatted(Formatting.GRAY), false);
            return 0;
        }

        int wanted = Math.min(count, allowance);
        int given = 0;
        while (given < wanted) {
            int batch = Math.min(item.getMaxCount(), wanted - given);
            ItemStack stack = new ItemStack(item, batch);
            if (!player.getInventory().insertStack(stack)) player.dropItem(stack, false);
            given += batch;
        }
        return given;
    }



    /**
     * A line fit to say out loud.
     *
     * Cuts anything from the first brace onward. Models routinely write their
     * sentence and then the object they were asked for, and the object reached
     * Minecraft chat verbatim — braces, quotes and all.
     */
    private static String cleanLine(String raw) {
        if (raw == null) return null;

        String text = raw.replace("```json", " ").replace("```", " ");

        int brace = text.indexOf('{');
        if (brace >= 0) text = text.substring(0, brace);

        text = text.replaceAll("\\s+", " ").trim();

        // Whatever is left must read as a sentence, not as leftover syntax.
        if (text.contains("\"say\"") || text.contains("\"give\"") || text.contains("\"item\"")) {
            return null;
        }
        return text.isBlank() ? null : text;
    }

    /** Thanks and small talk, which deserve an answer but not another delivery. */
    private static boolean isCourtesy(String message) {
        String text = message.toLowerCase(Locale.ROOT).replaceAll("[^a-z ]", " ").trim();
        if (text.isEmpty()) return false;

        // Anything naming a quantity is a request, however politely it is put.
        if (message.matches(".*\\d.*")) return false;

        for (String word : new String[]{"give", "bring", "need", "want", "fetch", "get me",
                "hand me", "more", "another", "some"}) {
            if (text.contains(word)) return false;
        }

        for (String word : new String[]{"thank", "thanks", "ty", "cheers", "nice", "cool",
                "great", "awesome", "lol", "ok", "okay", "good"}) {
            if (text.contains(word)) return true;
        }
        return false;
    }

    /** Whether a line is claiming to hand something over. */
    private static boolean soundsLikeGiving(String line) {
        if (line == null) return false;
        String text = line.toLowerCase(Locale.ROOT);
        return text.contains("here you go") || text.contains("here are") || text.contains("here is")
                || text.contains("hand") || text.contains("take these") || text.contains("take this")
                || text.contains("giving") || text.contains("for you");
    }

    private void speak(MinecraftServer server, String line) {
        Text text = Text.literal("<").formatted(Formatting.GRAY)
                .append(Text.literal("Ember").formatted(Formatting.GOLD))
                .append(Text.literal("> ").formatted(Formatting.GRAY))
                .append(Text.literal(line).formatted(Formatting.WHITE));
        server.getPlayerManager().broadcast(text, false);
    }

    private void remember(String asked, String answered) {
        history.addLast(new LlmClient.Message("user", asked));
        history.addLast(new LlmClient.Message("assistant", answered));
        while (history.size() > HISTORY) history.removeFirst();
    }

    /** Models wrap JSON in ```json fences no matter how firmly you ask them not to. */
    private static String stripFence(String raw) {
        String text = raw.trim();
        if (text.startsWith("```")) {
            int firstBreak = text.indexOf('\n');
            if (firstBreak > 0) text = text.substring(firstBreak + 1);
            int fence = text.lastIndexOf("```");
            if (fence >= 0) text = text.substring(0, fence);
        }
        return text.trim();
    }
}
