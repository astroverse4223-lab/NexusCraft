package dev.nexuscraft.ember;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * config/ember.properties.
 *
 * Written on first run so there is something to edit rather than a file you
 * have to know the keys of. The defaults point at a local Ollama, because that
 * is what is already running on the machine this ships with.
 */
public final class EmberConfig {

    private static EmberConfig current;

    public final String baseUrl;
    public final String model;
    public final String apiKey;
    public final int timeoutSeconds;
    public final double temperature;
    /** False turns the talking off entirely and leaves the lantern behaviour. */
    public final boolean chat;
    /** How many items Ember will hand over in one go. */
    public final int giveLimit;

    private EmberConfig(Properties p) {
        this.baseUrl = p.getProperty("baseUrl", "http://127.0.0.1:11434/v1").trim();
        this.model = p.getProperty("model", "qwen2.5:7b-instruct").trim();
        this.apiKey = p.getProperty("apiKey", "").trim();
        this.timeoutSeconds = parseInt(p.getProperty("timeoutSeconds"), 120, 5, 600);
        this.temperature = parseDouble(p.getProperty("temperature"), 0.25);
        this.chat = !"false".equalsIgnoreCase(p.getProperty("chat", "true").trim());
        this.giveLimit = parseInt(p.getProperty("giveLimit"), 64, 1, 640);
    }

    public static synchronized EmberConfig get() {
        if (current == null) current = load();
        return current;
    }

    /** Forgets what was read, so an edited file takes effect without a restart. */
    public static synchronized void reload() {
        current = null;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("ember.properties");
    }

    private static EmberConfig load() {
        Properties properties = new Properties();
        Path path = file();

        if (Files.exists(path)) {
            try (InputStream in = Files.newInputStream(path)) {
                properties.load(in);
            } catch (IOException e) {
                Ember.LOG.warn("could not read ember.properties, using defaults: {}", e.getMessage());
            }
        } else {
            write(path);
        }

        return new EmberConfig(properties);
    }

    private static void write(Path path) {
        try {
            Files.createDirectories(path.getParent());
            try (OutputStream out = Files.newOutputStream(path)) {
                out.write(TEMPLATE.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            }
            Ember.LOG.info("wrote a default {}", path);
        } catch (IOException e) {
            Ember.LOG.warn("could not write ember.properties: {}", e.getMessage());
        }
    }

    private static final String TEMPLATE = """
            # Ember — the lantern keeper.
            #
            # Anything speaking the OpenAI chat-completions API works here. The
            # default is the Ollama most people already have running locally.
            # For Ollama the address must end in /v1.

            baseUrl=http://127.0.0.1:11434/v1
            model=qwen2.5:7b-instruct
            apiKey=

            # The first question of a session is the slow one: Ollama has to
            # load the model into memory before it can answer, which on a 7B
            # model takes most of a minute. Later answers are seconds.
            timeoutSeconds=120

            # Kept low on purpose. Ember has to write a line and fill a list of
            # items at the same time, and a high temperature makes it say it is
            # handing something over while leaving the list empty. The warmth
            # comes from the character, not from the sampling.
            temperature=0.25

            # false leaves the lantern working and stops it talking.
            chat=true

            # The most it will hand over at once, however nicely you ask.
            giveLimit=64
            """;

    private static int parseInt(String raw, int fallback, int min, int max) {
        if (raw == null) return fallback;
        try {
            return Math.max(min, Math.min(max, Integer.parseInt(raw.trim())));
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private static double parseDouble(String raw, double fallback) {
        if (raw == null) return fallback;
        try {
            return Double.parseDouble(raw.trim());
        } catch (NumberFormatException e) {
            return fallback;
        }
    }
}
