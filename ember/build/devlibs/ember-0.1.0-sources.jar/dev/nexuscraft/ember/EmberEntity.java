package dev.nexuscraft.ember;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.storage.ReadView;
import net.minecraft.storage.WriteView;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.List;
import java.util.UUID;

/**
 * A lantern that decided to follow someone.
 *
 * It hovers at about knee height, never lands, and spends itself burning back
 * the dark the player is walking into. Movement is steered directly rather than
 * pathfound: a thing with no legs has no business asking the navigator how to
 * walk somewhere, and steering cannot get wedged in a doorway the way a ground
 * path can.
 */
public class EmberEntity extends PathAwareEntity {

    private static final TrackedData<Byte> MOOD =
            DataTracker.registerData(EmberEntity.class, TrackedDataHandlerRegistry.BYTE);

    /**
     * Where it sits relative to the player.
     *
     * Forward and out to the left, at head height. The first version tucked it
     * behind the shoulder so it would not block the view, which succeeded
     * completely: it was never in the view at all, and a companion you cannot
     * see is just a noise in the dark. Ahead and off to one side keeps it in
     * peripheral vision without sitting on the crosshair.
     */
    private static final double HOVER_HEIGHT = 1.35;
    private static final double HOVER_AHEAD = 1.15;
    private static final double HOVER_SIDE = 1.25;

    /** Beyond this it stops trying to fly and simply appears. */
    private static final double TELEPORT_DISTANCE = 22.0;

    /** A hostile this close to the player is worth flaring at. */
    private static final double FLARE_RANGE = 4.0;

    /** Cooldown between flares, in ticks — twelve seconds. */
    private static final int FLARE_COOLDOWN = 240;

    private UUID ownerId;
    private PlayerEntity cachedOwner;

    private final Lightbringer lightbringer = new Lightbringer();

    private int flareCooldown;
    private int sulkTicks;

    /** Drives the bob and the hand sway; advanced client-side too. */
    private float phase;

    public EmberEntity(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world);
        this.setNoGravity(true);
        this.setPersistent();

        /*
         * It drifts through blocks rather than into them.
         *
         * Steering toward a point beside the player puts that point inside a
         * tree trunk several times a minute in any forest. Solid, it wedged
         * itself in the wood and suffocated — a companion that dies to an oak
         * is not a companion. Passing through is the lesser strangeness, and
         * it is what the vanilla vex does for the same reason.
         */
        this.noClip = true;
    }

    /**
     * The world cannot kill it.
     *
     * Suffocation, falling, fire, drowning, cactus: every one of them was
     * reachable by a thing that hovers where it is told to and cannot choose to
     * step around anything. Being hit by its owner is handled separately — that
     * does not hurt it either, it just stops helping for a while.
     */
    @Override
    public boolean isInvulnerableTo(ServerWorld world, DamageSource source) {
        return true;
    }

    public static DefaultAttributeContainer.Builder createEmberAttributes() {
        return PathAwareEntity.createMobAttributes()
                .add(EntityAttributes.MAX_HEALTH, 12.0)
                .add(EntityAttributes.MOVEMENT_SPEED, 0.4)
                .add(EntityAttributes.FOLLOW_RANGE, 32.0);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(MOOD, Mood.CONTENT.id());
    }

    /* ------------------------------------------------------------- owner */

    public void setOwner(PlayerEntity player) {
        this.ownerId = player.getUuid();
        this.cachedOwner = player;
    }

    public UUID getOwnerId() {
        return ownerId;
    }

    private PlayerEntity owner() {
        if (cachedOwner != null && !cachedOwner.isRemoved()) return cachedOwner;
        if (ownerId == null) return null;
        cachedOwner = this.getEntityWorld().getPlayerByUuid(ownerId);
        return cachedOwner;
    }

    /* -------------------------------------------------------------- mood */

    public Mood getMood() {
        return Mood.byId(this.dataTracker.get(MOOD));
    }

    private void setMood(Mood mood) {
        if (getMood() != mood) this.dataTracker.set(MOOD, mood.id());
    }

    public float getPhase() {
        return phase;
    }

    /* -------------------------------------------------------------- tick */

    @Override
    public void tick() {
        super.tick();
        phase += 0.1f;

        if (this.getEntityWorld().isClient()) {
            emitFlame();
            return;
        }

        PlayerEntity owner = owner();
        if (owner == null || owner.isRemoved()) {
            // Nobody to keep. Fade rather than linger as scenery.
            if (this.age > 200) this.discard();
            return;
        }

        if (flareCooldown > 0) flareCooldown--;
        if (sulkTicks > 0) sulkTicks--;

        follow(owner);
        decideMood(owner);
        help(owner);
    }

    /**
     * Steers toward a point beside the player rather than pathing to them.
     *
     * The target sits behind the shoulder they are facing away from, so it
     * lights what is ahead without floating through the middle of the view.
     */
    private void follow(PlayerEntity owner) {
        Vec3d facing = Vec3d.fromPolar(0.0f, owner.getYaw()).normalize();
        Vec3d left = new Vec3d(-facing.z, 0.0, facing.x).normalize();

        Vec3d want = owner.getEntityPos()
                .add(facing.multiply(HOVER_AHEAD))
                .add(left.multiply(HOVER_SIDE))
                .add(0.0, HOVER_HEIGHT, 0.0);

        double distance = this.getEntityPos().distanceTo(want);

        if (distance > TELEPORT_DISTANCE) {
            this.refreshPositionAndAngles(want.x, want.y, want.z, this.getYaw(), this.getPitch());
            this.setVelocity(Vec3d.ZERO);
            return;
        }

        if (distance > 0.35) {
            Vec3d push = want.subtract(this.getEntityPos()).normalize().multiply(Math.min(0.09 * distance, 0.42));
            this.setVelocity(this.getVelocity().multiply(0.72).add(push));
        } else {
            this.setVelocity(this.getVelocity().multiply(0.6));
        }

        // A slow bob, so it never looks parked in mid-air.
        this.setVelocity(this.getVelocity().add(0.0, MathHelper.sin(phase * 0.6f) * 0.004, 0.0));

        // With noClip on, this is a straight translation; nothing to collide with.
        this.move(net.minecraft.entity.MovementType.SELF, this.getVelocity());

        // Turned toward whoever it is following, so the lit face is the one
        // you see rather than the back of the shutters.
        this.lookAtEntity(owner, 30.0f, 30.0f);
        this.bodyYaw = this.getYaw();
    }

    /** What it is feeling, in priority order — sulking outranks everything. */
    private void decideMood(PlayerEntity owner) {
        if (sulkTicks > 0) {
            setMood(Mood.SULKING);
            return;
        }
        if (owner.getHealth() <= owner.getMaxHealth() * 0.4f) {
            setMood(Mood.WORRIED);
            return;
        }
        if (!nearbyHostiles(owner, 8.0).isEmpty()) {
            setMood(Mood.ALERT);
            return;
        }
        setMood(Mood.CONTENT);
    }

    private List<LivingEntity> nearbyHostiles(PlayerEntity owner, double radius) {
        Box box = owner.getBoundingBox().expand(radius);
        return this.getEntityWorld().getEntitiesByClass(LivingEntity.class, box,
                candidate -> candidate instanceof Monster && candidate.isAlive());
    }

    /* ------------------------------------------------------------- helping */

    private void help(PlayerEntity owner) {
        if (!(this.getEntityWorld() instanceof ServerWorld world)) return;

        // A sulking Ember genuinely stops working. The shutters are shut.
        if (getMood() == Mood.SULKING) return;

        lightbringer.tick(world, this, owner);
        thaw(owner);

        if (getMood() == Mood.ALERT && flareCooldown <= 0) {
            List<LivingEntity> close = nearbyHostiles(owner, FLARE_RANGE);
            if (!close.isEmpty()) flare(world, close);
        }
    }

    /**
     * Throws the shutters wide.
     *
     * Blinds what is closing on the player and lights the ground for a moment.
     * It does no damage on purpose — Ember is not a weapon, it buys the three
     * seconds you need to turn around.
     */
    private void flare(ServerWorld world, List<LivingEntity> targets) {
        flareCooldown = FLARE_COOLDOWN;

        for (LivingEntity target : targets) {
            target.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(
                    net.minecraft.entity.effect.StatusEffects.BLINDNESS, 60, 0, false, false));
            target.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(
                    net.minecraft.entity.effect.StatusEffects.GLOWING, 120, 0, false, false));
        }

        world.spawnParticles(ParticleTypes.END_ROD, this.getX(), this.getY() + 0.3, this.getZ(),
                60, 0.45, 0.45, 0.45, 0.08);
        world.spawnParticles(ParticleTypes.FLAME, this.getX(), this.getY() + 0.3, this.getZ(),
                20, 0.3, 0.3, 0.3, 0.02);
        world.playSound(null, this.getBlockPos(), SoundEvents.ITEM_FIRECHARGE_USE,
                SoundCategory.NEUTRAL, 0.7f, 1.6f);
    }

    /** Being a lantern is worth something in the cold. */
    private void thaw(PlayerEntity owner) {
        if (owner.getFrozenTicks() > 0) {
            owner.setFrozenTicks(Math.max(0, owner.getFrozenTicks() - 4));
        }
    }

    /* ------------------------------------------------------------ reactions */

    @Override
    public boolean damage(ServerWorld world, DamageSource source, float amount) {
        // Hit by the one it follows: it does not fight back, it stops helping.
        if (source.getAttacker() instanceof PlayerEntity player
                && player.getUuid().equals(ownerId)) {
            sulkTicks = 400;
            world.playSound(null, this.getBlockPos(), SoundEvents.BLOCK_LANTERN_BREAK,
                    SoundCategory.NEUTRAL, 0.6f, 0.7f);
            return false;
        }
        return super.damage(world, source, amount);
    }

    /** The flame, drawn as particles so the colour needs no second texture. */
    private void emitFlame() {
        Mood mood = getMood();
        if (mood == Mood.SULKING) return;

        if (this.random.nextInt(mood == Mood.ALERT ? 1 : 3) != 0) return;

        double x = this.getX() + (this.random.nextDouble() - 0.5) * 0.16;
        double y = this.getY() + 0.28 + this.random.nextDouble() * 0.1;
        double z = this.getZ() + (this.random.nextDouble() - 0.5) * 0.16;

        this.getEntityWorld().addParticleClient(switch (mood) {
            case ALERT -> ParticleTypes.END_ROD;
            case WORRIED -> ParticleTypes.SOUL_FIRE_FLAME;
            default -> ParticleTypes.SMALL_FLAME;
        }, x, y, z, 0.0, 0.01, 0.0);
    }

    /* ---------------------------------------------------------- persistence */

    @Override
    protected void writeCustomData(WriteView view) {
        super.writeCustomData(view);
        if (ownerId != null) view.putString("Owner", ownerId.toString());
        view.putBoolean("Lighting", lightbringer.isEnabled());
        view.putInt("Sulk", sulkTicks);
    }

    @Override
    protected void readCustomData(ReadView view) {
        super.readCustomData(view);
        String owner = view.getString("Owner", "");
        if (!owner.isEmpty()) {
            try {
                ownerId = UUID.fromString(owner);
            } catch (IllegalArgumentException ignored) {
                ownerId = null;
            }
        }
        lightbringer.setEnabled(view.getBoolean("Lighting", true));
        sulkTicks = view.getInt("Sulk", 0);
    }

    public Lightbringer lightbringer() {
        return lightbringer;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean canBeLeashed() {
        return false;
    }

    @Override
    protected boolean shouldDropLoot(ServerWorld world) {
        return false;
    }
}
