package dev.nexuscraft.ember;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1309;
import net.minecraft.class_1569;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_3218;

/**
 * What Ember saw while it was over there.
 *
 * Throwing it into a room you would rather not walk into already lights the
 * place. This is the other half of why you would do that: it comes back with
 * something to say about what was in there.
 *
 * Everything here is a scan of blocks and entities the server already has
 * loaded — the same kind of look the torch placement takes, over a wider area
 * and for different things. The findings are written as plain facts and handed
 * to the model to say in its own words, so the report sounds like a lantern
 * describing a cave rather than a list.
 */
public final class Survey {

    /** How far it looks from where it landed. */
    private static final int RADIUS = 12;
    private static final int VERTICAL = 8;

    /** Ores worth mentioning. Coal and copper are not news. */
    private static final Map<class_2248, String> NOTABLE = new LinkedHashMap<>();

    static {
        NOTABLE.put(class_2246.field_10442, "diamonds");
        NOTABLE.put(class_2246.field_29029, "diamonds");
        NOTABLE.put(class_2246.field_22109, "ancient debris");
        NOTABLE.put(class_2246.field_10013, "emeralds");
        NOTABLE.put(class_2246.field_29220, "emeralds");
        NOTABLE.put(class_2246.field_10571, "gold");
        NOTABLE.put(class_2246.field_29026, "gold");
        NOTABLE.put(class_2246.field_10212, "iron");
        NOTABLE.put(class_2246.field_29027, "iron");
        NOTABLE.put(class_2246.field_10080, "redstone");
        NOTABLE.put(class_2246.field_29030, "redstone");
        NOTABLE.put(class_2246.field_10090, "lapis");
    }

    private Survey() {
    }

    /**
     * What is here, and a signature for deciding whether it is news.
     *
     * The prose changes every time it drifts a block — one mob becomes two, an
     * ore comes into range — and comparing prose meant reporting the same cave
     * three times in twenty seconds. The signature is the *kinds* of thing
     * present, with no counts in it, so a second mob wandering in is not a
     * discovery.
     */
    public record Findings(String facts, String signature) {}

    public static Findings of(class_3218 world, class_2338 from) {
        Map<String, Integer> ores = new LinkedHashMap<>();
        int openings = 0;
        boolean lava = false;
        boolean water = false;
        String spawner = null;
        class_2338 chest = null;

        int deepest = from.method_10264();

        for (int dx = -RADIUS; dx <= RADIUS; dx++) {
            for (int dz = -RADIUS; dz <= RADIUS; dz++) {
                for (int dy = -VERTICAL; dy <= VERTICAL; dy++) {
                    class_2338 pos = from.method_10069(dx, dy, dz);
                    class_2248 block = world.method_8320(pos).method_26204();

                    String ore = NOTABLE.get(block);
                    if (ore != null && exposed(world, pos)) {
                        ores.merge(ore, 1, Integer::sum);
                    }

                    if (block == class_2246.field_10260) {
                        spawner = describeSpawner(world, pos);
                    } else if (block == class_2246.field_10034 || block == class_2246.field_16328) {
                        if (chest == null) chest = pos;
                    } else if (block == class_2246.field_10164) {
                        lava = true;
                    } else if (block == class_2246.field_10382) {
                        water = true;
                    }

                    // Air at the edge of the scan means the space keeps going.
                    if (world.method_8320(pos).method_26215()) {
                        if (Math.abs(dx) == RADIUS || Math.abs(dz) == RADIUS
                                || Math.abs(dy) == VERTICAL) {
                            openings++;
                        }
                        if (pos.method_10264() < deepest) deepest = pos.method_10264();
                    }
                }
            }
        }

        List<class_1309> hostiles = world.method_8390(class_1309.class,
                new net.minecraft.class_238(from).method_1014(RADIUS),
                candidate -> candidate instanceof class_1569 && candidate.method_5805());

        if (ores.isEmpty() && spawner == null && chest == null && hostiles.isEmpty()
                && !lava && openings < 40) {
            return null;
        }

        // Kinds only — no numbers, so counts drifting is not news.
        StringBuilder kinds = new StringBuilder();
        if (spawner != null) kinds.append("spawner:").append(spawner).append(' ');
        if (!hostiles.isEmpty()) kinds.append("mobs ");
        for (String ore : ores.keySet()) kinds.append(ore).append(' ');
        if (chest != null) kinds.append("chest ");
        if (lava) kinds.append("lava ");
        if (water) kinds.append("water ");
        kinds.append(openings > 120 ? "vast" : openings > 40 ? "open" : "small");

        StringBuilder facts = new StringBuilder("You were thrown into a space and had a look around. ");

        if (spawner != null) facts.append("There is a ").append(spawner).append(" spawner in here. ");
        if (!hostiles.isEmpty()) {
            facts.append("You can see ").append(hostiles.size())
                 .append(hostiles.size() == 1 ? " hostile mob. " : " hostile mobs. ");
        }
        if (!ores.isEmpty()) {
            facts.append("There is exposed ");
            facts.append(String.join(", ", ores.keySet()));
            facts.append(". ");
        }
        /*
         * Named, not located.
         *
         * Coordinates in its speech read as a debug line wearing a character's
         * name. It is leading them there or it is not; either way a lantern
         * says "there is a chest", not three numbers.
         */
        if (chest != null) facts.append("There is a chest in here. ");
        if (lava) facts.append("There is lava. ");
        if (water) facts.append("There is water. ");

        if (openings > 120) facts.append("The space keeps going a long way in several directions. ");
        else if (openings > 40) facts.append("It opens out further on. ");
        else facts.append("It is a small space, more or less enclosed. ");

        // How far down, not to what altitude — the same reason as the chest.
        if (deepest < from.method_10264() - 6) {
            facts.append("It drops away below you, about ").append(from.method_10264() - deepest)
                 .append(" blocks down. ");
        }

        return new Findings(facts.toString().trim(), kinds.toString().trim());
    }

    /** Only ore you could actually reach counts as worth mentioning. */
    private static boolean exposed(class_3218 world, class_2338 pos) {
        for (class_2350 face : class_2350.values()) {
            if (world.method_8320(pos.method_10093(face)).method_26215()) return true;
        }
        return false;
    }

    private static String describeSpawner(class_3218 world, class_2338 pos) {
        var entity = world.method_8321(pos);
        if (entity instanceof net.minecraft.class_2636 spawner) {
            var type = spawner.method_11390().method_8283(world, pos);
            if (type != null) return type.method_5864().method_5897().getString().toLowerCase();
        }
        return "mob";
    }
}
