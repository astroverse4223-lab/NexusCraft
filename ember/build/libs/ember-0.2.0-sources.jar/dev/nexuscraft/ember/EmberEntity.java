package dev.nexuscraft.ember;

import java.util.List;
import java.util.UUID;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1314;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

/**
 * A lantern that decided to follow someone.
 *
 * It hovers at about knee height, never lands, and spends itself burning back
 * the dark the player is walking into. Movement is steered directly rather than
 * pathfound: a thing with no legs has no business asking the navigator how to
 * walk somewhere, and steering cannot get wedged in a doorway the way a ground
 * path can.
 */
public class EmberEntity extends class_1314 {

    private static final class_2940<Byte> MOOD =
            class_2945.method_12791(EmberEntity.class, class_2943.field_13319);

    /** Tracked so the client can pose it in the hand rather than mid-air. */
    private static final class_2940<Byte> CARRY =
            class_2945.method_12791(EmberEntity.class, class_2943.field_13319);

    /**
     * How grown it is, sent to the client.
     *
     * The client cannot read the growth file — it is the server's — and the
     * flame is drawn client-side, so the stage has to travel with the entity
     * like the mood does.
     */
    private static final class_2940<Byte> STAGE =
            class_2945.method_12791(EmberEntity.class, class_2943.field_13319);

    /**
     * Where it sits relative to the player.
     *
     * Forward and out to the left, at head height. The first version tucked it
     * behind the shoulder so it would not block the view, which succeeded
     * completely: it was never in the view at all, and a companion you cannot
     * see is just a noise in the dark. Ahead and off to one side keeps it in
     * peripheral vision without sitting on the crosshair.
     */
    /*
     * Above the eyeline, slightly ahead and a little to one side.
     *
     * This took three wrong answers. Behind the shoulder it was never in view
     * at all. A metre in front put it squarely on the crosshair, so mining a
     * block swung at the lantern instead. Out to the side hid it again and
     * meant whipping the camera round to click it.
     *
     * Up solves all three, because the crosshair almost never goes there: you
     * look level or down to mine and forward to fight, and a lantern hanging
     * above your eyeline is visible the whole time without ever being in front
     * of what you are aiming at. It is also where you would actually hold a
     * lamp to see by.
     *
     * The eyes sit at 1.62, so 2.15 puts it about half a block above them —
     * roughly twenty-five degrees up at this distance, which is comfortably
     * clear of the crosshair and a small glance away from being clicked.
     */
    private static final double HOVER_HEIGHT = 2.15;
    private static final double HOVER_AHEAD = 0.85;
    private static final double HOVER_SIDE = 0.65;

    /** How far it slides aside when it is sitting on the crosshair. */
    private static final double DODGE = 1.1;

    /** Beyond this it stops trying to fly and simply appears. */
    private static final double TELEPORT_DISTANCE = 22.0;

    /** A hostile this close to the player is worth flaring at. */
    private static final double FLARE_RANGE = 4.0;

    /** Cooldown between flares, in ticks — twelve seconds. */
    private static final int FLARE_COOLDOWN = 240;

    private UUID ownerId;
    private class_1657 cachedOwner;

    private final Lightbringer lightbringer = new Lightbringer();

    private int flareCooldown;
    private int sulkTicks;

    /** Drives the bob and the hand sway; advanced client-side too. */
    private float phase;

    /** Ticks left sitting where it was thrown before it comes back. */
    private int plantedFor;

    /** So it only complains about the lava once per dunking. */
    private boolean complainedAboutLava;

    /** How long it has been in the air, to give up on a throw that goes wrong. */
    private int airborne;

    /** Where it is leading, and null when it is not leading anywhere. */
    private net.minecraft.class_2338 leadingTo;

    /** Ticks since it last said how far there was left to go. */
    private int sinceProgress;

    /** Counts down to the look around after being thrown somewhere. */
    private int surveyIn;

    /** Where it is drifting to while it explores the space it landed in. */
    private class_243 roamingTo;

    /** The kinds of thing it last described here, so it does not repeat itself. */
    private String saidAbout;

    /** How many more times it may speak about this throw. */
    private int reportsLeft;

    /**
     * What it is carrying for its owner.
     *
     * Sized to the stage it has reached, and resized when it grows — the extra
     * slots are the one reward for growing that can be used rather than only
     * looked at. Never shrunk: an Ember cannot un-grow, and a smaller satchel
     * would have to drop what was in it.
     */
    private net.minecraft.class_1277 satchel =
            new net.minecraft.class_1277(0);

    public EmberEntity(class_1299<? extends class_1314> type, class_1937 world) {
        super(type, world);
        this.method_5875(true);
        this.method_5971();

        /*
         * It drifts through blocks rather than into them.
         *
         * Steering toward a point beside the player puts that point inside a
         * tree trunk several times a minute in any forest. Solid, it wedged
         * itself in the wood and suffocated — a companion that dies to an oak
         * is not a companion. Passing through is the lesser strangeness, and
         * it is what the vanilla vex does for the same reason.
         */
        this.field_5960 = true;
    }

    /**
     * The world cannot kill it.
     *
     * Suffocation, falling, fire, drowning, cactus: every one of them was
     * reachable by a thing that hovers where it is told to and cannot choose to
     * step around anything. Being hit by its owner is handled separately — that
     * does not hurt it either, it just stops helping for a while.
     */
    @Override
    public boolean method_5679(class_3218 world, class_1282 source) {
        return true;
    }

    public static class_5132.class_5133 createEmberAttributes() {
        return class_1314.method_26828()
                .method_26868(class_5134.field_23716, 12.0)
                .method_26868(class_5134.field_23719, 0.4)
                .method_26868(class_5134.field_23717, 32.0);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(MOOD, Mood.CONTENT.id());
        builder.method_56912(CARRY, Carry.FOLLOWING.id());
        builder.method_56912(STAGE, Growth.Stage.SPARK.id());
    }

    /* ------------------------------------------------------------- owner */

    public void setOwner(class_1657 player) {
        this.ownerId = player.method_5667();
        this.cachedOwner = player;
    }

    public UUID getOwnerId() {
        return ownerId;
    }

    private class_1657 owner() {
        if (cachedOwner != null && !cachedOwner.method_31481()) return cachedOwner;
        if (ownerId == null) return null;
        cachedOwner = this.method_73183().method_18470(ownerId);
        return cachedOwner;
    }

    /* -------------------------------------------------------------- mood */

    public Mood getMood() {
        return Mood.byId(this.field_6011.method_12789(MOOD));
    }

    private void setMood(Mood mood) {
        if (getMood() != mood) this.field_6011.method_12778(MOOD, mood.id());
    }

    public float getPhase() {
        return phase;
    }

    public Carry getCarry() {
        return Carry.byId(this.field_6011.method_12789(CARRY));
    }

    public Growth.Stage getStage() {
        return Growth.Stage.byId(this.field_6011.method_12789(STAGE));
    }

    private void setStage(Growth.Stage stage) {
        if (getStage() != stage) this.field_6011.method_12778(STAGE, stage.id());
    }

    private void setCarry(Carry state) {
        if (getCarry() != state) this.field_6011.method_12778(CARRY, state.id());
    }

    /* -------------------------------------------------------------- tick */

    @Override
    public void method_5773() {
        super.method_5773();
        phase += 0.1f;

        if (this.method_73183().method_8608()) {
            emitFlame();
            return;
        }

        class_1657 owner = owner();
        if (owner == null || owner.method_31481()) {
            // Nobody to keep. Fade rather than linger as scenery — but never
            // take anything with it.
            if (this.field_6012 > 200) {
                spillSatchel();
                this.method_31472();
            }
            return;
        }

        if (flareCooldown > 0) flareCooldown--;
        if (sulkTicks > 0) sulkTicks--;

        /*
         * Once a second: note the day, and pick up any change of stage.
         *
         * Cheap enough to do often and not worth doing every tick — nothing
         * here changes faster than a Minecraft day.
         */
        if (this.field_6012 % 20 == 0 && ownerId != null) {
            Growth.seen(ownerId, this.method_73183().method_8532() / 24000L);
            Growth.Stage now = Growth.stageOf(ownerId);
            if (now != getStage()) {
                Growth.Stage was = getStage();
                setStage(now);
                if (this.field_6012 > 100) announceGrowth(owner, was, now);
            }
        }

        mindTheLava(owner);

        Carry state = getCarry();
        if (state == Carry.CARRIED) {
            beCarried(owner);
        } else if (state.follows()) {
            // Leading takes precedence over trailing at the shoulder.
            if (leadingTo != null) lead(owner);
            else follow(owner);
        } else {
            flight(owner);
        }

        decideMood(owner);
        help(owner);
    }

    /**
     * Steers toward a point beside the player rather than pathing to them.
     *
     * The target sits behind the shoulder they are facing away from, so it
     * lights what is ahead without floating through the middle of the view.
     */
    private void follow(class_1657 owner) {
        class_243 facing = class_243.method_1030(0.0f, owner.method_36454()).method_1029();
        class_243 left = new class_243(-facing.field_1350, 0.0, facing.field_1352).method_1029();

        /*
         * Beside the shoulder rather than out in front.
         *
         * It used to hover a metre ahead, which put it on the crosshair — so
         * left-clicking a block hit the lantern instead and the block never
         * broke. Level with the player and further out keeps it in view without
         * standing in front of the thing being looked at.
         */
        double side = HOVER_SIDE + (onTheCrosshair(owner) ? DODGE : 0.0);

        class_243 want = owner.method_73189()
                .method_1019(facing.method_1021(HOVER_AHEAD))
                .method_1019(left.method_1021(side))
                .method_1031(0.0, HOVER_HEIGHT, 0.0);

        double distance = this.method_73189().method_1022(want);

        if (distance > TELEPORT_DISTANCE) {
            this.method_5808(want.field_1352, want.field_1351, want.field_1350, this.method_36454(), this.method_36455());
            this.method_18799(class_243.field_1353);
            return;
        }

        /*
         * It steadies when you look straight at it.
         *
         * Grabbing a thing that hovers, bobs and follows meant chasing it with
         * the crosshair. Noticing that it is being looked at and holding still
         * is both easier to use and better in character than making it slower
         * all the time — it is paying attention to you.
         */
        if (beingReachedFor(owner)) {
            this.method_18799(this.method_18798().method_1021(0.35));
            this.method_5784(net.minecraft.class_1313.field_6308, this.method_18798());
            this.method_5951(owner, 30.0f, 30.0f);
            this.field_6283 = this.method_36454();
            return;
        }

        if (distance > 0.35) {
            class_243 push = want.method_1020(this.method_73189()).method_1029().method_1021(Math.min(0.09 * distance, 0.42));
            this.method_18799(this.method_18798().method_1021(0.72).method_1019(push));
        } else {
            this.method_18799(this.method_18798().method_1021(0.6));
        }

        // A slow bob, so it never looks parked in mid-air.
        this.method_18799(this.method_18798().method_1031(0.0, class_3532.method_15374(phase * 0.6f) * 0.004, 0.0));

        // With noClip on, this is a straight translation; nothing to collide with.
        this.method_5784(net.minecraft.class_1313.field_6308, this.method_18798());

        // Turned toward whoever it is following, so the lit face is the one
        // you see rather than the back of the shutters.
        this.method_5951(owner, 30.0f, 30.0f);
        this.field_6283 = this.method_36454();
    }



    /** Sends it wherever the player is looking. */
    private void throwFrom(class_1657 player) {
        setCarry(Carry.THROWN);
        airborne = 0;
        leadingTo = null;

        /*
         * Thrown from the player's hand, wherever it was standing.
         *
         * Now that a throw does not need it caught first, it can be sitting
         * twenty blocks away when the gesture happens — and an arc that starts
         * over there goes somewhere nobody aimed at.
         */
        class_243 from = player.method_33571().method_1019(player.method_5828(1.0f).method_1029().method_1021(0.6));
        this.method_5808(from.field_1352, from.field_1351 - 0.2, from.field_1350, player.method_36454(), 0.0f);

        class_243 aim = player.method_5828(1.0f).method_1029().method_1021(1.15);
        this.method_18800(aim.field_1352, aim.field_1351 + 0.18, aim.field_1350);

        method_5783(class_3417.field_14757, 0.7f, 1.5f);
    }

    /**
     * In the air, then sitting where it landed, then coming home.
     *
     * The arc is its own rather than the physics engine's: it has no gravity by
     * design, and turning that on and off around a throw is more moving parts
     * than falling slowly on purpose.
     */
    private void flight(class_1657 owner) {
        Carry state = getCarry();

        if (state == Carry.THROWN) {
            airborne++;

            /*
             * Solid while it is in the air, and only then.
             *
             * It drifts through blocks the rest of the time so it cannot wedge
             * itself in a tree, but a thrown lantern that ignores the floor
             * falls to the bottom of the world. Collision is turned on for the
             * throw and off again the moment it lands.
             */
            this.field_5960 = false;

            this.method_18799(this.method_18798().method_1021(0.97).method_1031(0.0, -0.032, 0.0));
            this.method_5784(net.minecraft.class_1313.field_6308, this.method_18798());

            boolean landed = this.method_24828()
                    || this.field_5976
                    || this.field_5992
                    || this.method_18798().method_1027() < 0.004;

            if (landed || airborne > 120) {
                setCarry(Carry.PLANTED);
                // Long enough to explore a room properly.
                plantedFor = 1200;
                surveyIn = 60;
                reportsLeft = 2;
                saidAbout = null;
                this.method_18799(class_243.field_1353);
                // Back to drifting, so it does not settle inside whatever it
                // happened to bounce off.
                this.field_5960 = true;
                method_5783(class_3417.field_17743, 0.7f, 0.9f);
            }
            return;
        }

        if (state == Carry.PLANTED) {
            roam();

            /*
             * A look around, two seconds after landing.
             *
             * Delayed rather than immediate so the dust settles and it has lit
             * a torch or two — reporting on a pitch-dark room the instant it
             * arrives would describe less than the player can already see.
             */
            if (surveyIn > 0 && --surveyIn == 0
                    && this.method_73183() instanceof class_3218 world
                    && owner instanceof net.minecraft.class_3222 served
                    && this.method_73183().method_8503() != null) {
                Survey.Findings saw = Survey.of(world, this.method_24515());

                /*
                 * Only when the kind of thing here has actually changed.
                 *
                 * Comparing the prose meant a second mob wandering into range
                 * counted as a discovery, and the same cave was described three
                 * times in twenty seconds. Two reports per throw is the ceiling
                 * regardless: it is scouting a room, not narrating one.
                 */
                if (saw != null && !saw.signature().equals(saidAbout) && reportsLeft > 0) {
                    saidAbout = saw.signature();
                    reportsLeft--;
                    Ember.voice().hear(this.method_73183().method_8503(), served, this,
                            "[Something is happening: " + saw.facts()
                                    + " Tell them what you found, in your own words, in a sentence "
                                    + "or two. Do not mention coordinates.]");
                }
            }

            // Another look every twenty-five seconds while it explores.
            if (plantedFor % 500 == 0 && plantedFor < 560) surveyIn = 1;

            if (--plantedFor <= 0) {
                roamingTo = null;
                saidAbout = null;
                setCarry(Carry.RETURNING);
                method_5783(class_3417.field_15197, 0.5f, 1.6f);
            }
            return;
        }

        if (state == Carry.RETURNING) {
            class_243 home = owner.method_73189().method_1031(0.0, HOVER_HEIGHT, 0.0);
            class_243 toward = home.method_1020(this.method_73189());

            if (toward.method_1027() < 2.2) {
                setCarry(Carry.FOLLOWING);
                return;
            }

            this.method_18799(this.method_18798().method_1021(0.6)
                    .method_1019(toward.method_1029().method_1021(0.55)));
            this.method_5784(net.minecraft.class_1313.field_6308, this.method_18798());
        }
    }

    /**
     * Rides on the shoulder of whoever picked it up.
     *
     * Held at the hand it hung out in front and read as a thing floating near
     * you rather than one you were carrying — you could see it, which is the
     * problem, because your own hand is not somewhere you look. A shoulder is
     * where something small and alive sits: behind the eyeline so it covers
     * nothing, and unmistakably carried in third person.
     *
     * Pinned exactly rather than steered, because something riding on you moves
     * with you and does not drift.
     */
    private void beCarried(class_1657 owner) {
        class_243 facing = class_243.method_1030(0.0f, owner.method_36454()).method_1029();
        class_243 right = new class_243(facing.field_1350, 0.0, -facing.field_1352).method_1029();

        // Sneaking lowers the player, and the perch follows so it does not
        // float free of the shoulder it is sitting on.
        double shoulder = (owner.method_5715() ? 1.05 : 1.32)
                + class_3532.method_15374(phase * 0.35f) * 0.015;

        class_243 perch = owner.method_73189()
                .method_1019(facing.method_1021(-0.14))
                .method_1019(right.method_1021(0.38))
                .method_1031(0.0, shoulder, 0.0);

        this.method_5808(perch.field_1352, perch.field_1351, perch.field_1350, owner.method_36454(), 0.0f);
        this.field_6283 = owner.method_36454();
        this.method_18799(class_243.field_1353);
    }

    /**
     * Lava. It cannot be hurt, and it would still rather not.
     *
     * The complaint goes through the ordinary voice, so it is spoken aloud and
     * remembered like anything else — and it only fires once per dunking, which
     * is the difference between a character and an alarm.
     */
    private void mindTheLava(class_1657 owner) {
        boolean burning = this.method_5771() || this.method_5809();

        if (!burning) {
            complainedAboutLava = false;
            return;
        }
        if (complainedAboutLava) return;
        complainedAboutLava = true;

        this.method_5646();
        method_5783(class_3417.field_15102, 0.8f, 1.2f);

        if (this.method_73183().method_8503() != null && owner instanceof net.minecraft.class_3222 served) {
            Ember.voice().hear(this.method_73183().method_8503(), served, this,
                    "[Something is happening: they have just thrown you into lava. You cannot be "
                            + "hurt by it and you are not in danger, but you hate it. Say so.]");
        }
    }



    /* ------------------------------------------------------------ satchel */

    public net.minecraft.class_1277 satchel() {
        resizeSatchel();
        return satchel;
    }

    /** Grows the satchel to fit the stage, keeping what is already in it. */
    private void resizeSatchel() {
        int want = Satchel.slotsFor(getStage());
        if (satchel.method_5439() >= want) return;

        net.minecraft.class_1277 bigger =
                new net.minecraft.class_1277(want);
        for (int slot = 0; slot < satchel.method_5439(); slot++) {
            bigger.method_5447(slot, satchel.method_5438(slot));
        }
        satchel = bigger;
    }

    /**
     * Opens it for whoever asked, if they are allowed to.
     *
     * Checked here rather than trusted from the client: ownership, reach, and
     * whether it has earned any slots at all.
     */
    public void openSatchel(net.minecraft.class_3222 player) {
        if (ownerId == null || !ownerId.equals(player.method_5667())) return;
        if (player.method_5739(this) > 8.0f) return;

        if (Satchel.slotsFor(getStage()) <= 0) {
            player.method_7353(net.minecraft.class_2561.method_43470(
                    "Ember has nowhere to put anything yet — it is still only a spark.")
                    .method_27692(net.minecraft.class_124.field_1080), true);
            return;
        }

        resizeSatchel();
        player.method_17355(new Satchel(this));
    }

    /**
     * Everything it was carrying, when it is dismissed or lost.
     *
     * Dropped rather than deleted. Losing a companion should not quietly eat
     * whatever you trusted it with.
     */
    public void spillSatchel() {
        if (!(this.method_73183() instanceof class_3218 world)) return;
        for (int slot = 0; slot < satchel.method_5439(); slot++) {
            net.minecraft.class_1799 stack = satchel.method_5438(slot);
            if (stack.method_7960()) continue;
            net.minecraft.class_1542 dropped = new net.minecraft.class_1542(
                    world, this.method_23317(), this.method_23318(), this.method_23321(), stack);
            world.method_8649(dropped);
        }
        satchel.method_5448();
    }

    /* ------------------------------------------------------------ leading */

    /** Starts leading somewhere, or stops if given null. */
    public void leadTo(net.minecraft.class_2338 target) {
        this.leadingTo = target;
        this.sinceProgress = 0;
        if (target != null) setCarry(Carry.FOLLOWING);
    }

    /** Drops whatever it was doing and comes back to the shoulder. */
    public void recall() {
        leadingTo = null;
        plantedFor = 0;
        roamingTo = null;
        saidAbout = null;
        if (getCarry() == Carry.PLANTED || getCarry() == Carry.THROWN) {
            setCarry(Carry.RETURNING);
        }
    }

    public boolean isLeading() {
        return leadingTo != null;
    }

    public net.minecraft.class_2338 leadingTo() {
        return leadingTo;
    }

    /**
     * Flies ahead along the way, and waits when you fall behind.
     *
     * Deliberately not pathfinding. It has no legs and no business solving a
     * maze; it moves toward the target and hangs at head height, and the player
     * does the walking. Waiting is the part that makes it feel like being led
     * rather than abandoned — beyond a dozen blocks it stops and holds until
     * you catch up.
     */
    private void lead(class_1657 owner) {
        double fromOwner = this.method_73189().method_1022(owner.method_73189());

        // Far enough ahead; wait rather than disappear over the hill.
        if (fromOwner > 12.0) {
            this.method_18799(this.method_18798().method_1021(0.55));
            this.method_5784(net.minecraft.class_1313.field_6308, this.method_18798());
            return;
        }

        class_243 target = new class_243(leadingTo.method_10263() + 0.5, leadingTo.method_10264() + 2.0, leadingTo.method_10260() + 0.5);
        class_243 toward = target.method_1020(this.method_73189());

        if (toward.method_1027() < 9.0) {
            arrive(owner);
            return;
        }

        // Ahead of the player, along the line to the target.
        class_243 ahead = owner.method_73189()
                .method_1019(toward.method_1029().method_1021(4.5))
                .method_1031(0.0, HOVER_HEIGHT, 0.0);

        class_243 push = ahead.method_1020(this.method_73189());
        if (push.method_1027() > 0.09) {
            this.method_18799(this.method_18798().method_1021(0.7)
                    .method_1019(push.method_1029().method_1021(Math.min(0.1 * push.method_1033(), 0.4))));
        }
        this.method_5784(net.minecraft.class_1313.field_6308, this.method_18798());
        this.method_5951(owner, 30.0f, 30.0f);
        this.field_6283 = this.method_36454();

        // A breadcrumb, so the direction is readable without watching it.
        if (this.field_6012 % 6 == 0 && this.method_73183() instanceof class_3218 world) {
            world.method_65096(net.minecraft.class_2398.field_27783,
                    this.method_23317(), this.method_23318() - 0.2, this.method_23321(), 1, 0.05, 0.05, 0.05, 0.0);
        }

        // Says how far is left, occasionally rather than constantly.
        if (++sinceProgress > 600 && owner instanceof net.minecraft.class_3222 served
                && this.method_73183().method_8503() != null) {
            sinceProgress = 0;
            int away = (int) Math.round(Math.sqrt(owner.method_24515().method_10262(leadingTo)));
            Ember.voice().hear(this.method_73183().method_8503(), served, this,
                    "[Something is happening: you are leading them somewhere and it is still about "
                            + away + " blocks away. Say something brief about the going.]");
        }
    }


    /**
     * Wanders the space it was thrown into.
     *
     * Landing and looking once is not scouting — the room does not change, so
     * every throw produced the same sentence. Drifting through the space means
     * it lights more of it, sees round corners, and has something new to say.
     *
     * Deliberately aimless rather than pathfound: it picks somewhere open
     * within a dozen blocks, goes there, picks again. A lantern exploring a
     * cave does not need a route, and one that solves the cave takes the
     * interesting part away from the player.
     */
    private void roam() {
        if (roamingTo == null || this.method_73189().method_1022(roamingTo) < 1.6) {
            roamingTo = somewhereOpen();
        }

        if (roamingTo != null) {
            class_243 toward = roamingTo.method_1020(this.method_73189());
            this.method_18799(this.method_18798().method_1021(0.78)
                    .method_1019(toward.method_1029().method_1021(0.055)));
        }

        this.method_18799(this.method_18798().method_1031(0.0, class_3532.method_15374(phase * 0.4f) * 0.004, 0.0));
        this.method_5784(net.minecraft.class_1313.field_6308, this.method_18798());
    }

    /**
     * An open spot to drift toward, or null if it is walled in.
     *
     * Tries a handful of directions and keeps the first with room in it, which
     * is enough to explore a cave and cheap enough to do every few seconds.
     */
    private class_243 somewhereOpen() {
        for (int attempt = 0; attempt < 8; attempt++) {
            double angle = this.field_5974.method_43058() * Math.PI * 2.0;
            double reach = 4.0 + this.field_5974.method_43058() * 7.0;

            class_243 candidate = this.method_73189().method_1031(
                    Math.cos(angle) * reach,
                    (this.field_5974.method_43058() - 0.45) * 4.0,
                    Math.sin(angle) * reach);

            net.minecraft.class_2338 at = net.minecraft.class_2338.method_49638(candidate);
            if (!this.method_73183().method_8320(at).method_26215()) continue;
            if (!this.method_73183().method_8320(at.method_10084()).method_26215()) continue;

            return candidate;
        }
        return null;
    }

    /** Arriving is worth saying out loud, and stops the leading. */
    private void arrive(class_1657 owner) {
        net.minecraft.class_2338 where = leadingTo;
        leadingTo = null;
        this.method_18799(class_243.field_1353);

        if (this.method_73183() instanceof class_3218 world) {
            world.method_65096(net.minecraft.class_2398.field_11207,
                    where.method_10263() + 0.5, where.method_10264() + 1.0, where.method_10260() + 0.5,
                    24, 0.3, 0.5, 0.3, 0.02);
        }
        method_5783(class_3417.field_17743, 0.7f, 1.5f);

        if (owner instanceof net.minecraft.class_3222 served
                && this.method_73183().method_8503() != null) {
            Ember.voice().hear(this.method_73183().method_8503(), served, this,
                    "[Something is happening: you have just led them to the place they asked for and "
                            + "you have arrived. Say so.]");
        }
    }



    /**
     * Whether it is sitting between the player and whatever they are aiming at.
     *
     * Being beside the shoulder is usually enough, but a player turning quickly
     * or looking sharply sideways can still sweep the crosshair onto it, and a
     * click meant for a block becomes a swing at the lantern. When that
     * happens it slides further out of the way rather than waiting to be told.
     *
     * Deliberately a wider cone than `beingReachedFor`, and the two disagree on
     * purpose: reaching for it is a slow, deliberate look, and this is anything
     * that would steal a click.
     */
    private boolean onTheCrosshair(class_1657 owner) {
        class_243 look = owner.method_5828(1.0f).method_1029();
        class_243 toward = this.method_73189().method_1031(0.0, 0.25, 0.0).method_1020(owner.method_33571());

        double range = toward.method_1033();
        if (range > 4.5) return false;

        // Looking sharply up is the one time an overhead lantern is in the way.
        if (owner.method_36455() < -35.0f) return true;

        // About fifteen degrees, and only while they are not deliberately
        // looking at it — otherwise it would dodge away from being picked up.
        return look.method_1026(toward.method_1029()) > 0.965 && !beingReachedFor(owner);
    }

    /**
     * Whether the owner is looking almost straight at it, from close by.
     *
     * The threshold is deliberately generous: this only makes it hold still, so
     * being slightly too eager costs nothing, and being too strict brings back
     * the chasing it exists to stop.
     */
    private boolean beingReachedFor(class_1657 owner) {
        if (this.method_73189().method_1022(owner.method_33571()) > 5.0) return false;

        class_243 look = owner.method_5828(1.0f).method_1029();
        class_243 toward = this.method_73189().method_1031(0.0, 0.25, 0.0)
                .method_1020(owner.method_33571()).method_1029();

        // About twenty degrees of cone.
        return look.method_1026(toward) > 0.94;
    }


    /**
     * Growing up is worth one line, when it happens.
     *
     * Said through the ordinary voice so it is spoken aloud and remembered like
     * anything else — and only once, because the stage only changes once.
     */
    private void announceGrowth(class_1657 owner, Growth.Stage was, Growth.Stage now) {
        if (!(owner instanceof net.minecraft.class_3222 served)) return;
        if (this.method_73183().method_8503() == null) return;

        if (this.method_73183() instanceof class_3218 world) {
            world.method_65096(net.minecraft.class_2398.field_11207,
                    this.method_23317(), this.method_23318() + 0.3, this.method_23321(), 30, 0.3, 0.4, 0.3, 0.04);
        }
        method_5783(class_3417.field_26980, 0.8f, 1.0f);

        Growth.Life life = Growth.of(ownerId);
        Ember.voice().hear(this.method_73183().method_8503(), served, this,
                "[Something is happening: you have just grown. You were " + was.word
                        + " and you are " + now.word + " now, after " + life.daysTogether()
                        + " days together and " + life.torches()
                        + " torches. Say something about that — quietly, not grandly.]");
    }

    /** What it is feeling, in priority order — sulking outranks everything. */
    private void decideMood(class_1657 owner) {
        if (sulkTicks > 0) {
            setMood(Mood.SULKING);
            return;
        }
        if (owner.method_6032() <= owner.method_6063() * 0.4f) {
            setMood(Mood.WORRIED);
            return;
        }
        if (!nearbyHostiles(owner, 8.0).isEmpty()) {
            setMood(Mood.ALERT);
            return;
        }
        setMood(Mood.CONTENT);
    }

    private List<class_1309> nearbyHostiles(class_1657 owner, double radius) {
        class_238 box = owner.method_5829().method_1014(radius);
        return this.method_73183().method_8390(class_1309.class, box,
                candidate -> candidate instanceof class_1569 && candidate.method_5805());
    }

    /* ------------------------------------------------------------- helping */

    private void help(class_1657 owner) {
        if (!(this.method_73183() instanceof class_3218 world)) return;

        // A sulking Ember genuinely stops working. The shutters are shut.
        if (getMood() == Mood.SULKING) return;

        /*
         * Thrown into a dark room, it lights that room — not wherever the
         * player happens to be standing. Anything else makes throwing it
         * pointless.
         */
        lightbringer.tick(world, this, getCarry() == Carry.PLANTED ? null : owner);
        thaw(owner);

        if (getMood() == Mood.ALERT && flareCooldown <= 0) {
            List<class_1309> close = nearbyHostiles(owner, FLARE_RANGE);
            if (!close.isEmpty()) flare(world, close);
        }
    }

    /**
     * Throws the shutters wide.
     *
     * Blinds what is closing on the player and lights the ground for a moment.
     * It does no damage on purpose — Ember is not a weapon, it buys the three
     * seconds you need to turn around.
     */
    private void flare(class_3218 world, List<class_1309> targets) {
        flareCooldown = getStage().flareCooldown;
        if (ownerId != null) Growth.flared(ownerId);

        for (class_1309 target : targets) {
            target.method_6092(new net.minecraft.class_1293(
                    net.minecraft.class_1294.field_5919, 60, 0, false, false));
            target.method_6092(new net.minecraft.class_1293(
                    net.minecraft.class_1294.field_5912, 120, 0, false, false));
        }

        world.method_65096(class_2398.field_11207, this.method_23317(), this.method_23318() + 0.3, this.method_23321(),
                60, 0.45, 0.45, 0.45, 0.08);
        world.method_65096(class_2398.field_11240, this.method_23317(), this.method_23318() + 0.3, this.method_23321(),
                20, 0.3, 0.3, 0.3, 0.02);
        world.method_8396(null, this.method_24515(), class_3417.field_15013,
                class_3419.field_15254, 0.7f, 1.6f);
    }

    /** Being a lantern is worth something in the cold. */
    private void thaw(class_1657 owner) {
        if (owner.method_32312() > 0) {
            owner.method_32317(Math.max(0, owner.method_32312() - 4));
        }
    }

    /* ------------------------------------------------------------ reactions */

    @Override
    public boolean method_64397(class_3218 world, class_1282 source, float amount) {
        // Hit by the one it follows: it does not fight back, it stops helping.
        if (source.method_5529() instanceof class_1657 player
                && player.method_5667().equals(ownerId)) {
            sulkTicks = 400;
            world.method_8396(null, this.method_24515(), class_3417.field_17745,
                    class_3419.field_15254, 0.6f, 0.7f);
            return false;
        }
        return super.method_64397(world, source, amount);
    }

    /** The flame, drawn as particles so the colour needs no second texture. */
    private void emitFlame() {
        Mood mood = getMood();
        if (mood == Mood.SULKING) return;

        if (this.field_5974.method_43048(mood == Mood.ALERT ? 1 : 3) != 0) return;

        double x = this.method_23317() + (this.field_5974.method_43058() - 0.5) * 0.16;
        double y = this.method_23318() + 0.28 + this.field_5974.method_43058() * 0.1;
        double z = this.method_23321() + (this.field_5974.method_43058() - 0.5) * 0.16;

        this.method_73183().method_8406(switch (mood) {
            case ALERT -> class_2398.field_11207;
            case WORRIED -> class_2398.field_22246;
            default -> class_2398.field_27783;
        }, x, y, z, 0.0, 0.01, 0.0);
    }

    /* ---------------------------------------------------------- persistence */

    @Override
    protected void method_5652(class_11372 view) {
        super.method_5652(view);
        if (ownerId != null) view.method_71469("Owner", ownerId.toString());
        view.method_71472("Lighting", lightbringer.isEnabled());
        view.method_71465("Sulk", sulkTicks);
        view.method_71465("Carry", getCarry().id());
        satchel.method_7660(view.method_71467("Satchel", net.minecraft.class_1799.field_24671));
    }

    @Override
    protected void method_5749(class_11368 view) {
        super.method_5749(view);
        String owner = view.method_71428("Owner", "");
        if (!owner.isEmpty()) {
            try {
                ownerId = UUID.fromString(owner);
            } catch (IllegalArgumentException ignored) {
                ownerId = null;
            }
        }
        lightbringer.setEnabled(view.method_71433("Lighting", true));
        sulkTicks = view.method_71424("Sulk", 0);
        // Never restored mid-throw: it would load in the air with nowhere to go.
        byte carried = (byte) view.method_71424("Carry", 0);
        setCarry(carried == Carry.CARRIED.id() ? Carry.CARRIED : Carry.FOLLOWING);
    }

    public Lightbringer lightbringer() {
        return lightbringer;
    }

    /**
     * A bigger target than it looks.
     *
     * Ember is half a block across and never stops moving, so clicking it was a
     * game of its own — you had to catch a bobbing thing the size of a helmet
     * before it drifted. The margin widens what the crosshair counts as a hit
     * without changing what is drawn, which is the same trick vanilla uses to
     * make arrows and boats catchable.
     */
    @Override
    public float method_5871() {
        return 0.45f;
    }

    /**
     * The crosshair cannot see it, and so cannot spend a click on it.
     *
     * This is the whole fix for a problem four different hovering positions
     * failed to solve: behind the player it was invisible, in front it ate
     * clicks meant for blocks, beside it was invisible again, above it fouled
     * fighting and building upward. Any position a crosshair can reach is a
     * position where it will eventually steal something.
     *
     * Its own keys find it instead, with a raycast that does not consult this —
     * so it is reachable when wanted and invisible to every ordinary click.
     */
    @Override
    public boolean method_5863() {
        return false;
    }

    /** For the same reason: nothing should ever swing at it by accident. */
    @Override
    public boolean method_5732() {
        return false;
    }

    /** Called by the keybinding path, since right-click can no longer reach it. */
    public void grabToggle(net.minecraft.class_3222 player) {
        if (ownerId == null || !ownerId.equals(player.method_5667())) return;
        if (player.method_5739(this) > 8.0f) return;

        if (getCarry() == Carry.CARRIED) {
            setCarry(Carry.FOLLOWING);
            this.field_5960 = true;
            method_5783(class_3417.field_17743, 0.5f, 1.4f);
            player.method_7353(net.minecraft.class_2561.method_43470("Ember lifts off again.")
                    .method_27692(net.minecraft.class_124.field_1080), true);
        } else {
            setCarry(Carry.CARRIED);
            this.field_5960 = true;
            plantedFor = 0;
            leadingTo = null;
            this.method_18799(class_243.field_1353);
            method_5783(class_3417.field_17743, 0.6f, 1.1f);
            player.method_7353(net.minecraft.class_2561.method_43470(
                    "Ember settles onto your shoulder. Sneak and press again to throw it.")
                    .method_27692(net.minecraft.class_124.field_1080), true);
        }
    }

    /** Also called from the keybinding path. */
    public void throwFor(net.minecraft.class_3222 player) {
        if (ownerId == null || !ownerId.equals(player.method_5667())) return;
        if (player.method_5739(this) > 8.0f) return;
        throwFrom(player);
    }

    @Override
    public boolean method_5810() {
        return false;
    }

    @Override
    public boolean method_5931() {
        return false;
    }

    @Override
    protected boolean method_27071(class_3218 world) {
        return false;
    }
}
