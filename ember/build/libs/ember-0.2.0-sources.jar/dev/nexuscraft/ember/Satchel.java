package dev.nexuscraft.ember;

import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_2561;
import net.minecraft.class_3908;

/**
 * What Ember carries for you.
 *
 * Promised when the growth stages were sketched and then not built, which is
 * how someone ends up hunting for an inventory that never existed. It is the
 * one reward for growing that you can use rather than only look at: a spark
 * carries nothing, and an old Ember has been trusted with two rows.
 *
 * Backed by an ordinary chest screen rather than a bespoke one — there is
 * nothing about holding nine items that needs new interface, and a screen
 * everybody already knows how to use is better than a clever one.
 */
public final class Satchel implements class_3908 {

    private final EmberEntity ember;

    public Satchel(EmberEntity ember) {
        this.ember = ember;
    }

    /** How many slots a stage has earned. Nine to a row. */
    public static int slotsFor(Growth.Stage stage) {
        return switch (stage) {
            case SPARK -> 0;
            case STEADY -> 9;
            case BRIGHT -> 18;
            case ELDER -> 27;
        };
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43470("Ember");
    }

    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        class_1277 inventory = ember.satchel();
        int rows = Math.max(1, Math.min(3, inventory.method_5439() / 9));

        /*
         * Built directly rather than through the createGeneric helpers.
         *
         * Only the three-row helper takes an inventory in 1.21.11; the others
         * make an empty one of their own, which would show the player an empty
         * chest and quietly drop anything they put in it.
         */
        return new class_1707(
                switch (rows) {
                    case 1 -> net.minecraft.class_3917.field_18664;
                    case 2 -> net.minecraft.class_3917.field_18665;
                    default -> net.minecraft.class_3917.field_17326;
                },
                syncId, playerInventory, inventory, rows);
    }
}
