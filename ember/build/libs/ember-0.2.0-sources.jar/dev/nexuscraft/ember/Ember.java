package dev.nexuscraft.ember;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Ember — a lantern keeper that follows you and burns the dark back.
 *
 * Deliberately not part of Hollow. Hollow is a face with no body that grows
 * less friendly the longer you keep it; this is a body with no face that simply
 * helps, and the two would undercut each other sharing a jar.
 */
public class Ember implements ModInitializer {

    public static final String MOD_ID = "ember";

    public static final Logger LOG = LoggerFactory.getLogger("Ember");

    /** Stamped at build time so a running game can be told from a stale one. */
    public static final String BUILD = "0.2.0-1712";

    /** One voice for the server, holding the short conversation history. */
    private static final Voice VOICE = new Voice();

    /** So the entity itself can speak when something happens to it. */
    public static Voice voice() {
        return VOICE;
    }

    public static class_2960 id(String path) {
        return class_2960.method_60655(MOD_ID, path);
    }

    public static final class_5321<class_1299<?>> EMBER_KEY =
            class_5321.method_29179(class_7924.field_41266, id("ember"));

    public static final class_1299<EmberEntity> EMBER = class_2378.method_39197(
            class_7923.field_41177,
            EMBER_KEY,
            class_1299.class_1300.method_5903(EmberEntity::new, class_1311.field_17715)
                    .method_17687(0.5f, 0.6f)
                    .method_19947()
                    .method_5905(EMBER_KEY));

    public static final class_5321<class_1792> LANTERN_KEY =
            class_5321.method_29179(class_7924.field_41197, id("ember_lantern"));

    public static final class_1792 EMBER_LANTERN = class_2378.method_39197(
            class_7923.field_41178,
            LANTERN_KEY,
            new EmberLanternItem(new class_1792.class_1793()
                    .method_63686(LANTERN_KEY)
                    .method_7889(1)));

    @Override
    public void onInitialize() {
        /*
         * Says which build this is, in the log and once in chat on join.
         *
         * Minecraft loads mods at startup, so a jar replaced while the game is
         * running has no effect — and leaving a world to the title screen does
         * not reload anything either. That cost a round trip of "it is still
         * broken" against "the fix is installed", with both true at once.
         */
        LOG.info("Ember {} loaded", BUILD);

        FabricDefaultAttributeRegistry.register(EMBER, EmberEntity.createEmberAttributes());

        /*
         * Middle-click travels from the client, and is checked here.
         *
         * The client says which entity; the server decides whether that player
         * owns it and can reach it. A request is not a permission.
         */
        net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry.playC2S()
                .register(dev.nexuscraft.ember.net.EmberAction.ID,
                          dev.nexuscraft.ember.net.EmberAction.CODEC);

        net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.registerGlobalReceiver(
                dev.nexuscraft.ember.net.EmberAction.ID,
                (payload, context) -> context.server().execute(() -> {
                    var player = context.player();
                    var entity = player.method_51469().method_8469(payload.entityId());
                    if (!(entity instanceof EmberEntity ember)) return;

                    switch (payload.action()) {
                        case dev.nexuscraft.ember.net.EmberAction.GRAB -> ember.grabToggle(player);
                        case dev.nexuscraft.ember.net.EmberAction.THROW -> ember.throwFor(player);
                        case dev.nexuscraft.ember.net.EmberAction.SATCHEL -> ember.openSatchel(player);
                        default -> { }
                    }
                }));

        /*
         * In the creative menu beside the other tools.
         *
         * A registered item that belongs to no group exists and is completely
         * unreachable: it will not appear in creative, and the only way to hold
         * one is to already know the recipe. The first build shipped that way,
         * and the mod looked broken because nothing could be found.
         */
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060)
                .register(entries -> entries.method_45421(EMBER_LANTERN));

        /*
         * Home is wherever they last slept.
         *
         * The game's own definition, so it needs no explaining and is right by
         * default; saying "this is home" overrides it.
         */
        net.fabricmc.fabric.api.entity.event.v1.EntitySleepEvents.STOP_SLEEPING.register(
                (entity, sleepingPos) -> {
                    if (!(entity instanceof net.minecraft.class_3222 player)) return;
                    long day = player.method_51469().method_8532() / 24000L;
                    Waypoints.setHome(player.method_5667(),
                            player.method_51469().method_27983().method_29177().toString(), sleepingPos, day);
                });

        EmberCommand.register();

        /*
         * Ember answers when its own owner speaks near it.
         *
         * Gated on the owner rather than on everyone: on a server, a lantern
         * that replies to every line of chat is noise, and four of them
         * replying at once is unusable.
         */
        /*
         * Load the model before anyone asks it anything.
         *
         * Without this the first question of a session pays the whole model
         * load and times out, which reads as the mod being broken rather than
         * as Ollama being cold.
         */
        ServerLifecycleEvents.SERVER_STARTED.register(server -> Warmth.warm());
        // And give it straight back when they stop playing.
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> Warmth.release());

        /*
         * Deaths, written by the code rather than the model.
         *
         * Where and how someone died is a fact, and Ember is not always in the
         * conversation when it happens — asking the model to remember it would
         * mean only remembering the ones it was told about.
         */
        net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents.AFTER_DEATH.register(
                (entity, source) -> {
                    if (!(entity instanceof net.minecraft.class_3222 player)) return;
                    long day = player.method_51469().method_8532() / 24000L;
                    var at = player.method_24515();
                    Journal.remember(player.method_5667(), day,
                            "Died to " + source.method_5525() + " at " + at.method_10263() + ", " + at.method_10264()
                                    + ", " + at.method_10260() + ".");

                    // The same fact as coordinates, so Ember can walk them back.
                    Waypoints.setDeath(player.method_5667(),
                            player.method_51469().method_27983().method_29177().toString(), at, day);
                });
        net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.DISCONNECT.register(
                (handler, server) -> {
                    dev.nexuscraft.ember.voice.Ears.forget(handler.method_32311().method_5667());
                    Notices.forget(handler.method_32311().method_5667());
                    VOICE.forget(handler.method_32311().method_5667());
                });
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            Warmth.tick();

            /*
             * Anything worth mentioning unprompted.
             *
             * Checked twice a second rather than every tick — none of it
             * changes faster than that, and the scan for exposed ore is the
             * most expensive thing the mod does.
             */
            if (server.method_3780() % 10 == 0) {
                for (var player : server.method_3760().method_14571()) {
                    if (!(player.method_51469() instanceof net.minecraft.class_3218 world)) continue;

                    List<EmberEntity> mine = world.method_8390(
                            EmberEntity.class,
                            player.method_5829().method_1014(16.0),
                            candidate -> player.method_5667().equals(candidate.getOwnerId()));
                    if (mine.isEmpty()) continue;

                    String worthSaying = Notices.spot(world, player, mine.get(0));
                    if (worthSaying != null) VOICE.hear(server, player, mine.get(0), worthSaying);
                }
            }

            /*
             * Anything said out loud, once the speaker stops.
             *
             * Ears buffers the microphone and transcribes on its own thread;
             * this is where a finished sentence arrives, on the server thread,
             * and it is treated exactly as though it had been typed.
             */
            dev.nexuscraft.ember.voice.Ears.tick((speaker, heard) -> server.execute(() -> {
                var player = server.method_3760().method_14602(speaker);
                if (player == null) return;

                List<EmberEntity> mine = player.method_51469().method_8390(
                        EmberEntity.class,
                        player.method_5829().method_1014(24.0),
                        candidate -> speaker.equals(candidate.getOwnerId()));
                if (mine.isEmpty()) return;

                // Shown as well as heard, so there is a record of what it
                // thought you said when it answers the wrong question.
                player.method_7353(net.minecraft.class_2561.method_43470("you said: " + heard)
                        .method_27692(net.minecraft.class_124.field_1063), false);

                VOICE.hear(server, player, mine.get(0), heard);
            }));
        });

        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> {
            String text = message.method_46291().getString().trim();
            if (text.isEmpty() || text.startsWith("/")) return;

            List<EmberEntity> nearby = sender.method_51469().method_8390(
                    EmberEntity.class,
                    sender.method_5829().method_1014(24.0),
                    candidate -> sender.method_5667().equals(candidate.getOwnerId()));

            if (nearby.isEmpty()) return;
            VOICE.hear(sender.method_51469().method_8503(), sender, nearby.get(0), text);
        });
    }
}
