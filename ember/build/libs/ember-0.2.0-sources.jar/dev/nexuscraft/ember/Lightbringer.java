package dev.nexuscraft.ember;

import net.minecraft.class_1657;
import net.minecraft.class_1944;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2555;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * The part that actually earns its keep: putting torches where the dark is.
 *
 * A spawn needs block light zero, which is a thing the game already knows and
 * the player never can. Rather than lighting everything on sight, this looks
 * only at the places a mob could actually appear in front of the player, and
 * fixes the nearest one every few seconds — the room brightens as you walk
 * through it, which reads as company rather than as a floodlight.
 */
public class Lightbringer {

    /** Ticks between placements. Deliberately unhurried. */
    private static final int INTERVAL = 45;

    /**
     * How far up and down it will consider.
     *
     * The horizontal reach comes from how grown Ember is; this does not, because
     * a taller search finds spots on ledges nobody walks on.
     */
    private static final int VERTICAL = 3;

    /** Nothing is placed closer than this to the last one. */
    private static final double SPACING = 4.5;

    private boolean enabled = true;
    private int cooldown;
    private class_2338 lastPlaced;

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean toggle() {
        enabled = !enabled;
        return enabled;
    }

    /**
     * A pass over the dark nearby.
     *
     * `owner` may be null, which means Ember has been thrown somewhere and
     * should light where it is sitting rather than where the player is
     * standing — otherwise throwing it into a cave lights the field you threw
     * it from.
     */
    public void tick(class_3218 world, EmberEntity ember, class_1657 owner) {
        if (!enabled) return;
        if (cooldown-- > 0) return;
        /*
         * How hard it works, and how far it can see to work, both follow how
         * grown it is — which is the whole point of growing.
         */
        Growth.Stage stage = ember.getStage();
        cooldown = owner == null ? stage.lightInterval / 3 : stage.lightInterval;

        class_2338 spot = findDarkSpot(world,
                owner == null ? ember.method_24515() : owner.method_24515(), stage.lightRadius);
        if (spot == null) return;

        class_2680 torch = torchFor(world, spot);
        if (torch == null) return;

        if (!world.method_8501(spot, torch)) return;

        lastPlaced = spot;
        if (ember.getOwnerId() != null) Growth.placedTorch(ember.getOwnerId());
        world.method_65096(net.minecraft.class_2398.field_27783,
                spot.method_10263() + 0.5, spot.method_10264() + 0.5, spot.method_10260() + 0.5, 6, 0.1, 0.1, 0.1, 0.01);
        world.method_8396(null, spot, class_3417.field_14718, class_3419.field_15245, 0.4f, 1.5f);
    }

    /**
     * The nearest place a mob could spawn in front of the player.
     *
     * Searched nearest-first so the light lands where it is most useful rather
     * than at whichever corner the loop happened to reach first.
     */
    private class_2338 findDarkSpot(class_3218 world, class_2338 origin, int radius) {
        class_2338 best = null;
        double bestDistance = Double.MAX_VALUE;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                for (int dy = -VERTICAL; dy <= VERTICAL; dy++) {
                    class_2338 pos = origin.method_10069(dx, dy, dz);

                    if (world.method_8314(class_1944.field_9282, pos) > 0) continue;
                    if (!world.method_8320(pos).method_26215()) continue;

                    /*
                     * Under open sky, only after dark.
                     *
                     * This used to skip every position the sky could reach,
                     * which sounded right — the sun handles those — and meant
                     * Ember did nothing whatsoever on the surface, including at
                     * midnight, which is precisely when the surface is the most
                     * dangerous place to stand. Daylight is the sun's problem;
                     * night is not.
                     */
                    if (world.method_8311(pos) && world.method_8314(class_1944.field_9284, pos) > 7) continue;

                    double distance = pos.method_10262(origin);
                    if (distance >= bestDistance) continue;
                    if (lastPlaced != null && Math.sqrt(pos.method_10262(lastPlaced)) < SPACING) continue;
                    if (!canHoldTorch(world, pos)) continue;

                    best = pos;
                    bestDistance = distance;
                }
            }
        }

        return best;
    }

    private boolean canHoldTorch(class_3218 world, class_2338 pos) {
        return torchFor(world, pos) != null;
    }

    /**
     * A standing torch where there is a floor, a wall torch where there is not.
     *
     * Placing a floor torch with nothing under it drops it as an item the
     * moment the block update runs, which looks exactly like Ember littering.
     */
    private class_2680 torchFor(class_3218 world, class_2338 pos) {
        class_2680 floor = world.method_8320(pos.method_10074());
        if (floor.method_26206(world, pos.method_10074(), class_2350.field_11036)) {
            return class_2246.field_10336.method_9564();
        }

        for (class_2350 facing : class_2350.class_2353.field_11062) {
            class_2338 behind = pos.method_10093(facing.method_10153());
            class_2680 wall = world.method_8320(behind);
            if (!wall.method_26206(world, behind, facing)) continue;

            class_2680 torch = class_2246.field_10099.method_9564()
                    .method_11657(class_2741.field_12481, facing);
            if (torch.method_26184(world, pos)) return torch;
        }

        return null;
    }

    /** Kept so the class reads as owning the block choice, not guessing at it. */
    static boolean isTorch(class_2248 block) {
        return block == class_2246.field_10336 || block instanceof class_2555;
    }
}
