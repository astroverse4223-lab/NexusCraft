package dev.nexuscraft.ember;

import net.minecraft.class_1657;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

/**
 * What Ember can actually see, written for a model to read.
 *
 * The first version knew nothing at all, and it showed: asked how long it had
 * been alive it said "since the darkness fell", which is the sort of line
 * something produces when it has no facts and has to reach for atmosphere.
 * Given the hour, the biome, the light it is standing in and what it has been
 * doing, it can say something true instead — and true is what makes a companion
 * feel present rather than scripted.
 */
public final class Surroundings {

    private Surroundings() {
    }

    public static String describe(class_3218 world, class_1657 player, EmberEntity ember) {
        StringBuilder out = new StringBuilder();

        long time = world.method_8532() % 24000L;
        out.append("It is ").append(partOfDay(time))
           .append(" (day ").append(world.method_8532() / 24000L).append("). ");

        if (world.method_8419()) out.append(world.method_8546() ? "A storm is overhead. " : "It is raining. ");

        class_2338 at = player.method_24515();
        out.append("You are in ")
           .append(world.method_23753(at).method_40230().map(k -> k.method_29177().method_12832().replace('_', ' '))
                   .orElse("somewhere unfamiliar"))
           .append(" at height ").append(at.method_10264()).append(". ");

        int block = world.method_8314(class_1944.field_9282, at);
        int sky = world.method_8314(class_1944.field_9284, at);
        if (block <= 0 && sky <= 7) {
            out.append("It is dark enough here for things to spawn. ");
        } else if (block > 0) {
            out.append("There is torchlight here. ");
        }

        if (world.method_27983() != null) {
            String dimension = world.method_27983().method_29177().method_12832();
            if (!dimension.equals("overworld")) out.append("You are in the ").append(dimension).append(". ");
        }

        out.append("The player has ").append(Math.round(player.method_6032()))
           .append(" of ").append(Math.round(player.method_6063())).append(" hearts");
        if (player.method_7344().method_7586() <= 6) out.append(" and is hungry");
        out.append(". ");

        if (ember != null) {
            out.append("Your shutters are ").append(switch (ember.getMood()) {
                case CONTENT -> "half open and your flame is steady";
                case ALERT -> "thrown wide — something hostile is close";
                case WORRIED -> "drawn in, your flame gone blue, because the player is hurt";
                case SULKING -> "shut, because the player hit you";
            }).append(". ");

            out.append(ember.lightbringer().isEnabled()
                    ? "You are lighting the dark as you go."
                    : "You have been told to stop placing torches.");
        }

        return out.toString().trim();
    }

    private static String partOfDay(long time) {
        if (time < 1000) return "just after dawn";
        if (time < 5000) return "morning";
        if (time < 7000) return "the middle of the day";
        if (time < 11000) return "afternoon";
        if (time < 13000) return "dusk";
        if (time < 16000) return "early night";
        if (time < 22000) return "the dead of night";
        return "the hour before dawn";
    }
}
