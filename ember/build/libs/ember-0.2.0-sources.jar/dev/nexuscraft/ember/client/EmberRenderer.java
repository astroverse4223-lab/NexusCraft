package dev.nexuscraft.ember.client;

import dev.nexuscraft.ember.Ember;
import dev.nexuscraft.ember.EmberEntity;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_5617;
import net.minecraft.class_927;

/**
 * Draws an Ember.
 *
 * The only interesting thing here is the easing: the mood's openness is a step
 * function, and stepping the shutters straight to it made the model snap
 * between poses like a switch. Easing toward the target instead gives a flare
 * that throws open and a sulk that closes slowly, which is most of the
 * character.
 */
public class EmberRenderer extends class_927<EmberEntity, EmberRenderState, EmberModel> {

    private static final class_2960 TEXTURE = Ember.id("textures/entity/ember.png");

    public EmberRenderer(class_5617.class_5618 context) {
        super(context, new EmberModel(context.method_32167(EmberClient.EMBER_LAYER)), 0.3f);
    }

    @Override
    public EmberRenderState method_55269() {
        return new EmberRenderState();
    }

    @Override
    public void updateRenderState(EmberEntity entity, EmberRenderState state, float tickDelta) {
        super.method_62355(entity, state, tickDelta);

        state.mood = entity.getMood();
        state.grown = entity.getStage().ordinal() / 3.0f;
        state.phase = entity.getPhase() + tickDelta * 0.1f;

        float target = state.mood.openness();
        // Opening is quick and closing is slow, which is how a shutter behaves
        // and also how the mood reads: alarm arrives, sulking settles.
        float rate = target > state.openness ? 0.35f : 0.06f;
        state.openness = class_3532.method_16439(rate, state.openness, target);
    }

    @Override
    public class_2960 getTexture(EmberRenderState state) {
        return TEXTURE;
    }
}
