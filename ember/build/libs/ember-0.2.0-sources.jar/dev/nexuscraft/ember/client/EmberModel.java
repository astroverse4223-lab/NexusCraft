package dev.nexuscraft.ember.client;

import net.minecraft.class_3532;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;

/**
 * The shape of a lantern that decided to follow someone.
 *
 * A squat body with two hinged shutters, a cage of struts over the top, and two
 * cube hands that float free of it — there are no arms, because a thing with no
 * face needs its hands to do the talking and arms would only damp them.
 *
 * Every moving part is driven by two numbers: the phase, which never stops, and
 * the openness, which the mood decides. Between them the model idles, breathes,
 * flinches and shuts, without a single keyframe.
 */
public class EmberModel extends class_583<EmberRenderState> {

    private final class_630 field_54014;
    private final class_630 body;
    private final class_630 shutterLeft;
    private final class_630 shutterRight;
    private final class_630 handLeft;
    private final class_630 handRight;
    private final class_630 core;

    public EmberModel(class_630 root) {
        super(root);
        this.field_54014 = root;
        this.body = root.method_32086("body");
        this.shutterLeft = body.method_32086("shutter_left");
        this.shutterRight = body.method_32086("shutter_right");
        this.core = body.method_32086("core");
        this.handLeft = root.method_32086("hand_left");
        this.handRight = root.method_32086("hand_right");
    }

    public static class_5607 getTexturedModelData() {
        class_5609 data = new class_5609();
        class_5610 root = data.method_32111();

        /*
         * The body hangs from 24 rather than standing on 0: entity models are
         * built downward from the origin, and an Ember never touches the floor.
         */
        class_5610 body = root.method_32117("body",
                class_5606.method_32108()
                        // Lantern box.
                        .method_32101(0, 0).method_32097(-3.0f, -6.0f, -3.0f, 6, 6, 6)
                        // Cap above it, slightly proud.
                        .method_32101(0, 12).method_32097(-3.5f, -7.5f, -3.5f, 7, 2, 7)
                        // Foot ring below.
                        .method_32101(0, 21).method_32097(-2.5f, 0.0f, -2.5f, 5, 1, 5),
                class_5603.method_32090(0.0f, 20.0f, 0.0f));

        // The flame's housing, small and set inside the box.
        body.method_32117("core",
                class_5606.method_32108()
                        .method_32101(28, 0).method_32098(-1.5f, -4.5f, -1.5f, 3, 3, 3, new class_5605(0.0f)),
                class_5603.field_27701);

        /*
         * Shutters hinge on the back edge so they open outward like a book,
         * which reads at distance far better than sliding panels.
         */
        shutter(body, "shutter_left", -3.0f, -1.0f, 40, 0);
        shutter(body, "shutter_right", 3.0f, 0.0f, 40, 12);

        // Hands: free-floating cubes, no arms between them and the body.
        root.method_32117("hand_left",
                class_5606.method_32108().method_32101(28, 8).method_32097(-1.0f, -1.0f, -1.0f, 2, 2, 2),
                class_5603.method_32090(-5.0f, 17.0f, 0.0f));

        root.method_32117("hand_right",
                class_5606.method_32108().method_32101(28, 12).method_32097(-1.0f, -1.0f, -1.0f, 2, 2, 2),
                class_5603.method_32090(5.0f, 17.0f, 0.0f));

        return class_5607.method_32110(data, 64, 32);
    }

    /**
     * One shutter, hinged at the body's edge.
     *
     * Given real thickness rather than drawn as a plane: a zero-width cuboid
     * disappears entirely when seen edge-on, which is precisely the angle you
     * see it from when it swings open.
     */
    private static void shutter(class_5610 body, String name, float hinge, float inset, int u, int v) {
        body.method_32117(name,
                class_5606.method_32108().method_32101(u, v).method_32097(inset, -6.0f, -3.0f, 1, 6, 6),
                class_5603.method_32090(hinge, 0.0f, 0.0f));
    }

    @Override
    public void setAngles(EmberRenderState state) {
        super.method_2819(state);

        float phase = state.phase;

        // A slow breath through the whole body, never quite still.
        float bob = class_3532.method_15374(phase * 0.35f) * 0.6f;
        body.field_3656 = 20.0f + bob;
        body.field_3674 = class_3532.method_15374(phase * 0.21f) * 0.05f;

        /*
         * Shutters. Open is 100 degrees out; shut is flush. The mood picks the
         * target and the state has already eased toward it, so a flare snaps
         * and a sulk closes slowly.
         */
        float angle = state.openness * 1.75f;
        shutterLeft.field_3675 = -angle;
        shutterRight.field_3675 = angle;

        /*
         * The core pulses faster the wider the shutters stand, and sits larger
         * the older it is — a grown Ember has a visibly bigger flame, which is
         * the part of growing that can be seen from across a cave.
         */
        float pulse = (1.0f + state.grown * 0.45f)
                + class_3532.method_15374(phase * (0.4f + state.openness * 0.9f)) * 0.08f;
        core.field_37938 = pulse;
        core.field_37939 = pulse;
        core.field_37940 = pulse;

        /*
         * Hands drift on their own, a beat behind the body and out of phase
         * with each other — two cubes moving in lockstep read as machinery,
         * two cubes slightly disagreeing read as alive.
         */
        handLeft.field_3656 = 17.0f + bob + class_3532.method_15374(phase * 0.5f) * 0.9f;
        handRight.field_3656 = 17.0f + bob + class_3532.method_15374(phase * 0.5f + 2.1f) * 0.9f;

        float spread = 5.0f + state.openness * 1.6f;
        handLeft.field_3657 = -spread + class_3532.method_15362(phase * 0.31f) * 0.4f;
        handRight.field_3657 = spread - class_3532.method_15362(phase * 0.27f) * 0.4f;

        handLeft.field_3654 = class_3532.method_15374(phase * 0.44f) * 0.35f;
        handRight.field_3654 = class_3532.method_15374(phase * 0.39f + 1.2f) * 0.35f;
        handLeft.field_3675 = phase * 0.06f;
        handRight.field_3675 = -phase * 0.05f;
    }
}
