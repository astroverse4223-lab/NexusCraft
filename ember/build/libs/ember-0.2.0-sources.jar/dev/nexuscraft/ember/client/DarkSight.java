package dev.nexuscraft.ember.client;

import dev.nexuscraft.ember.Ember;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2390;
import net.minecraft.class_310;
import net.minecraft.class_638;

/**
 * Shows which blocks a mob could actually spawn on.
 *
 * The game knows the block light level of every position and the player never
 * can — you learn to squint at a cave floor and guess, and you are wrong often
 * enough to come back to a creeper in your basement. Ember spends its existence
 * fixing exactly this, so letting you see what it is looking at costs nothing
 * and turns cave-proofing from a guess into a job with an end.
 *
 * Drawn with particles rather than a custom render pass on purpose. 1.21.11
 * reworked the render pipeline, and a coloured dust particle at a block face is
 * a fraction of the surface area, works with every shader pack, and cannot
 * break anyone's game if it is wrong.
 */
public final class DarkSight {

    /** How far around the player it looks. */
    private static final int RADIUS = 12;
    private static final int VERTICAL = 6;

    /** Ticks between sweeps. Fast enough to feel live, slow enough to be free. */
    private static final int INTERVAL = 10;

    /** Nothing is drawn beyond this many marks, however dark the room is. */
    private static final int MAX_MARKS = 220;

    /** A dull red, which reads as a warning without drowning the torchlight. */
    private static final class_2390 MARK =
            new class_2390(0xE0553F, 0.8f);

    private static int cooldown;

    private DarkSight() {
    }

    /**
     * Called every client tick.
     *
     * Only while the lantern is actually in a hand: this is a tool you hold up
     * to look at a room, not a permanent overlay, and permanently marking the
     * world would make every cave look like a hazard sign.
     */
    public static void tick() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;
        if (client.method_1493()) return;

        if (!holdingTheLantern(client)) {
            cooldown = 0;
            return;
        }

        if (cooldown-- > 0) return;
        cooldown = INTERVAL;

        for (class_2338 spot : spawnableSpots(client.field_1687, client.field_1724.method_24515())) {
            client.field_1687.method_8406(MARK,
                    spot.method_10263() + 0.5,
                    // Just above the floor it would spawn on, so the mark reads
                    // as being on the surface rather than floating in the room.
                    spot.method_10264() + 0.08,
                    spot.method_10260() + 0.5,
                    0.0, 0.0, 0.0);
        }
    }

    private static boolean holdingTheLantern(class_310 client) {
        if (client.field_1724 == null) return false;
        return client.field_1724.method_6047().method_7909() == Ember.EMBER_LANTERN
                || client.field_1724.method_6079().method_7909() == Ember.EMBER_LANTERN;
    }

    /**
     * Every position a hostile could appear in.
     *
     * The real rule is block light zero, room for the mob, and something solid
     * underneath. Sky light is deliberately ignored: a spot that is safe at
     * noon because the sun reaches it is exactly the spot that kills you at
     * midnight, and marking it is the useful answer.
     */
    private static List<class_2338> spawnableSpots(class_638 world, class_2338 around) {
        List<class_2338> found = new ArrayList<>();

        for (int dx = -RADIUS; dx <= RADIUS && found.size() < MAX_MARKS; dx++) {
            for (int dz = -RADIUS; dz <= RADIUS && found.size() < MAX_MARKS; dz++) {
                for (int dy = -VERTICAL; dy <= VERTICAL && found.size() < MAX_MARKS; dy++) {
                    class_2338 pos = around.method_10069(dx, dy, dz);

                    if (world.method_8314(class_1944.field_9282, pos) > 0) continue;

                    // Room to stand: two blocks of space over a solid floor.
                    if (!world.method_8320(pos).method_26215()) continue;
                    if (!world.method_8320(pos.method_10084()).method_26215()) continue;

                    class_2338 below = pos.method_10074();
                    if (!world.method_8320(below).method_26206(world, below, class_2350.field_11036)) {
                        continue;
                    }

                    found.add(pos);
                }
            }
        }

        return found;
    }
}
