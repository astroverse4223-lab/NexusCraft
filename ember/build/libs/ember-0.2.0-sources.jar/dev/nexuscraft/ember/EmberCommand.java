package dev.nexuscraft.ember;

import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

import static net.minecraft.class_2170.method_9247;

/**
 * `/ember` — hands you the lantern.
 *
 * A convenience for testing and for handing one out on a server you run.
 * The survival route is the recipe, which the recipe book unlocks as soon as
 * you are carrying glowstone dust or an amethyst shard.
 */
public final class EmberCommand {

    private EmberCommand() {
    }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registry, environment) -> build(dispatcher));
    }

    private static void build(CommandDispatcher<class_2168> dispatcher) {
        /*
         * Operators only.
         *
         * 1.21.11 replaced `hasPermissionLevel(int)` with a predicate, so the
         * check goes through CommandManager's own gamemaster gate.
         *
         * This shipped ungated, which on a shared server let
         * anybody type it and be handed one for free — and in a survival world
         * it quietly made the recipe pointless. It is a testing convenience, so
         * it is gated like one; survival players craft the thing.
         */
        dispatcher.register(method_9247("ember")
                .requires(source -> class_2170.field_31839.method_75022(source.method_75037()))
                .executes(context -> {
                    class_3222 player = context.getSource().method_44023();
                    if (player == null) {
                        context.getSource().method_9226(() ->
                                class_2561.method_43470("Only a player can be given a lantern."), false);
                        return 0;
                    }

                    class_1799 stack = new class_1799(Ember.EMBER_LANTERN);
                    if (!player.method_31548().method_7394(stack)) {
                        player.method_7328(stack, false);
                    }

                    context.getSource().method_9226(() ->
                            class_2561.method_43470("Ember's Lantern. Right-click to call it, again to send it away, "
                                    + "sneak and right-click to stop it lighting things."), false);
                    return 1;
                }));
    }
}
