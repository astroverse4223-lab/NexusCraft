package dev.nexuscraft.ember;

import java.util.Locale;
import net.minecraft.class_1944;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3481;

/**
 * Finding a real place to match something Ember said.
 *
 * It could already lead you home and back to where you died, because those are
 * coordinates it was given. What it could not do was follow through on anything
 * it thought of itself — "follow me, I'll show you a nice spot by the river" is
 * a sentence about a place that exists only in the sentence.
 *
 * So the model names a *kind* of place and this finds one, which is the same
 * division of labour that made the item requests reliable: the model is good at
 * talking and bad at coordinates, and the world is right here to be searched.
 *
 * Everything is found by looking at blocks the server already has loaded. If
 * nothing matches, that is an answer too — better for Ember to say it cannot
 * see one than to lead you confidently into a field.
 */
public final class Landmarks {

    /** How far out to look. Beyond this the chunks are probably not loaded. */
    private static final int RADIUS = 64;

    /** Coarse steps: a landmark twelve blocks off is the same landmark. */
    private static final int STEP = 4;

    private Landmarks() {
    }

    /**
     * A place of the named kind, or null if none is in sight.
     *
     * The names are the ones a model reaches for unprompted, plus the obvious
     * synonyms — it will say "river" or "water" for the same thing and should
     * not have to guess which word this expects.
     */
    public static class_2338 find(class_3218 world, class_2338 from, String kind) {
        if (kind == null || kind.isBlank()) return null;
        String want = kind.toLowerCase(Locale.ROOT).trim();

        if (contains(want, "water", "river", "lake", "sea", "ocean", "coast", "shore")) {
            return nearest(world, from, Landmarks::isWatersEdge);
        }
        if (contains(want, "cave", "cavern", "tunnel", "underground", "dark")) {
            return nearest(world, from, Landmarks::isCaveMouth);
        }
        if (contains(want, "tree", "wood", "forest")) {
            return nearest(world, from, Landmarks::isWoodland);
        }
        if (contains(want, "high", "hill", "peak", "view", "lookout", "mountain")) {
            return highest(world, from);
        }
        if (contains(want, "open", "clear", "flat", "field", "meadow", "build")) {
            return nearest(world, from, Landmarks::isOpenGround);
        }
        if (contains(want, "shelter", "safe", "cover", "camp")) {
            return nearest(world, from, Landmarks::isSheltered);
        }

        return null;
    }

    /**
     * Whether the player asked to be taken anywhere.
     *
     * The model decides what kind of place to lead to, and it turns out it will
     * also decide *that* there is leading to be done — asked for mending it
     * answered "follow me" and set off for a cave, because a cave is where ore
     * is and it had drifted from repairing a tool to finding one. Being walked
     * somewhere is a big thing to do to someone who did not ask for it, so the
     * asking is read here rather than left to the model.
     */
    public static boolean wasAsked(String message) {
        if (message == null || message.isBlank()) return false;
        String text = message.toLowerCase(Locale.ROOT).replaceAll("[^a-z ]", " ");

        return contains(text,
                "show me", "take me", "lead me", "guide me", "bring me to",
                "where should", "where can", "where do i", "where is", "wheres",
                "find me a", "find a", "look for", "know anywhere", "know a good",
                "is there a", "are there any", "any caves", "any water",
                "somewhere", "anywhere", "nearby", "near here", "around here",
                "lets go", "let s go", "go somewhere", "explore");
    }

    /** The kinds Ember can actually find, for telling the model. */
    public static String kinds() {
        return "\"water\", \"cave\", \"trees\", \"high ground\", \"open ground\", \"shelter\"";
    }

    /* ------------------------------------------------------------ searching */

    private interface Test {
        boolean matches(class_3218 world, class_2338 at);
    }

    /**
     * The closest match, searched in rings outward.
     *
     * Outward rather than a full scan sorted afterwards: the nearest match is
     * almost always close, and a spiral finds it without looking at sixteen
     * thousand columns first.
     */
    private static class_2338 nearest(class_3218 world, class_2338 from, Test test) {
        for (int ring = STEP; ring <= RADIUS; ring += STEP) {
            for (int dx = -ring; dx <= ring; dx += STEP) {
                for (int dz = -ring; dz <= ring; dz += STEP) {
                    // Only the edge of this ring; the inside was already done.
                    if (Math.abs(dx) != ring && Math.abs(dz) != ring) continue;

                    class_2338 column = from.method_10069(dx, 0, dz);
                    class_2338 surface = world.method_8598(
                            class_2902.class_2903.field_13203, column);

                    if (test.matches(world, surface)) return surface;
                }
            }
        }
        return null;
    }

    /** The highest ground within reach, which is what "a view" means. */
    private static class_2338 highest(class_3218 world, class_2338 from) {
        class_2338 best = null;

        for (int dx = -RADIUS; dx <= RADIUS; dx += STEP) {
            for (int dz = -RADIUS; dz <= RADIUS; dz += STEP) {
                class_2338 surface = world.method_8598(
                        class_2902.class_2903.field_13203, from.method_10069(dx, 0, dz));

                if (world.method_8320(surface.method_10074()).method_26215()) continue;
                if (best == null || surface.method_10264() > best.method_10264()) best = surface;
            }
        }

        // Somewhere no higher than here is not a view.
        return best != null && best.method_10264() > from.method_10264() + 4 ? best : null;
    }

    /* ------------------------------------------------------------- the tests */

    /** Land, with water beside it — the bank rather than the middle. */
    private static boolean isWatersEdge(class_3218 world, class_2338 at) {
        if (world.method_8320(at.method_10074()).method_26204() == class_2246.field_10382) return false;
        if (!world.method_8320(at.method_10074()).method_26212(world, at.method_10074())) return false;

        for (class_2350 face : class_2350.class_2353.field_11062) {
            for (int reach = 1; reach <= 3; reach++) {
                class_2338 beside = at.method_10079(face, reach).method_10074();
                if (world.method_8320(beside).method_26204() == class_2246.field_10382) return true;
            }
        }
        return false;
    }

    /**
     * An opening that goes down into the dark.
     *
     * Air below the surface with no sky reaching it — which is what a cave mouth
     * is, and distinguishes one from a shaded overhang.
     */
    private static boolean isCaveMouth(class_3218 world, class_2338 at) {
        for (int down = 2; down <= 20; down++) {
            class_2338 below = at.method_10087(down);
            if (!world.method_8320(below).method_26215()) continue;
            if (world.method_8311(below)) continue;
            if (world.method_8314(class_1944.field_9284, below) > 4) continue;
            return true;
        }
        return false;
    }

    /** Several logs close together, which is a wood rather than a lone tree. */
    private static boolean isWoodland(class_3218 world, class_2338 at) {
        int logs = 0;
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                for (int dy = 0; dy <= 6; dy++) {
                    if (world.method_8320(at.method_10069(dx, dy, dz)).method_26164(class_3481.field_15475)) logs++;
                    if (logs >= 8) return true;
                }
            }
        }
        return false;
    }

    /** Flat, solid and unroofed — somewhere you could actually put a house. */
    private static boolean isOpenGround(class_3218 world, class_2338 at) {
        if (!world.method_8311(at)) return false;

        int level = at.method_10264();
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                class_2338 surface = world.method_8598(
                        class_2902.class_2903.field_13203, at.method_10069(dx, 0, dz));

                if (Math.abs(surface.method_10264() - level) > 1) return false;
                class_2248 under = world.method_8320(surface.method_10074()).method_26204();
                if (under == class_2246.field_10382 || under == class_2246.field_10164) return false;
            }
        }
        return true;
    }

    /** Solid over your head and solid at your back: a place to sit out a night. */
    private static boolean isSheltered(class_3218 world, class_2338 at) {
        if (world.method_8311(at)) return false;
        if (!world.method_8320(at).method_26215()) return false;
        if (!world.method_8320(at.method_10084()).method_26215()) return false;

        int walls = 0;
        for (class_2350 face : class_2350.class_2353.field_11062) {
            if (!world.method_8320(at.method_10093(face)).method_26215()) walls++;
        }
        return walls >= 2;
    }

    private static boolean contains(String text, String... words) {
        for (String word : words) {
            if (text.contains(word)) return true;
        }
        return false;
    }
}
