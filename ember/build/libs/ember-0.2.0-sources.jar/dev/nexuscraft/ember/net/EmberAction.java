package dev.nexuscraft.ember.net;

import dev.nexuscraft.ember.Ember;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Something the player wants done to their Ember.
 *
 * Everything used to go through right-clicking the entity, which meant Ember
 * had to be a target the crosshair could find — and a thing the crosshair can
 * find is a thing that steals the click you meant for a block. It was moved
 * behind the player, in front, beside and above trying to dodge that, and every
 * position was wrong somewhere: fighting, mining, placing, looking up.
 *
 * So it is no longer clickable at all. The client finds it with its own
 * raycast, which does not care whether the game considers it hittable, and asks
 * the server to do the thing. The server still decides whether it may.
 */
public record EmberAction(int entityId, int action) implements class_8710 {

    /** Take hold of it, or let it go if already held. */
    public static final int GRAB = 0;

    /** Throw it wherever the player is looking. */
    public static final int THROW = 1;

    /** Open what it is carrying. */
    public static final int SATCHEL = 2;

    public static final class_8710.class_9154<EmberAction> ID =
            new class_8710.class_9154<>(Ember.id("action"));

    public static final class_9139<class_9129, EmberAction> CODEC = class_9139.method_56435(
            class_9135.field_48550, EmberAction::entityId,
            class_9135.field_48550, EmberAction::action,
            EmberAction::new);

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
