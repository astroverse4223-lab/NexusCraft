package dev.nexuscraft.ember;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1309;
import net.minecraft.class_1548;
import net.minecraft.class_1569;
import net.minecraft.class_1944;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/**
 * The things Ember spots and mentions without being asked.
 *
 * A companion that only answers questions is a search box that floats. What
 * makes one feel present is that it looks at the same world you do and
 * occasionally says something first.
 *
 * The hard part is restraint, not detection. Something that comments on
 * everything is worse company than something silent, so each kind of remark has
 * its own cooldown, there is a floor between any two remarks at all, and
 * anything already obvious to the player is left unsaid — nobody needs to be
 * told there is a zombie in front of them.
 */
public final class Notices {

    /** Never two remarks closer together than this, whatever happens. */
    private static final long FLOOR_MS = 25_000;

    /** Per-kind cooldowns, so one thing cannot dominate. */
    private static final long DANGER_MS = 45_000;
    private static final long HURT_MS = 60_000;
    private static final long NIGHTFALL_MS = 8 * 60_000;
    private static final long ORE_MS = 90_000;

    /** Ores worth interrupting for. Coal and copper are not. */
    private static final Set<class_2248> WORTH_MENTIONING = Set.of(
            class_2246.field_10442, class_2246.field_29029,
            class_2246.field_22109,
            class_2246.field_10013, class_2246.field_29220);

    private static final Map<UUID, Map<String, Long>> SAID = new ConcurrentHashMap<>();

    private Notices() {
    }

    /** One thing worth saying, or null. Called a few times a second at most. */
    public static String spot(class_3218 world, class_3222 player, EmberEntity ember) {
        if (ember.getMood() == Mood.SULKING) return null;

        UUID who = player.method_5667();
        long now = System.currentTimeMillis();
        if (now - lastAnything(who) < FLOOR_MS) return null;

        String creeper = creeperBehind(world, player, who, now);
        if (creeper != null) return creeper;

        String hurt = badlyHurt(player, who, now);
        if (hurt != null) return hurt;

        String ore = orePassed(world, player, who, now);
        if (ore != null) return ore;

        return caughtOutside(world, player, who, now);
    }

    /**
     * Something dangerous behind them.
     *
     * Behind specifically: what is in front is already on their screen, and a
     * lantern announcing a zombie the player is currently looking at is the
     * sort of thing that makes people turn a mod off.
     */
    private static String creeperBehind(class_3218 world, class_3222 player,
                                        UUID who, long now) {
        if (!ready(who, "danger", DANGER_MS, now)) return null;

        class_243 facing = class_243.method_1030(0.0f, player.method_36454()).method_1029();
        List<class_1309> hostiles = world.method_8390(class_1309.class,
                player.method_5829().method_1014(9.0),
                candidate -> candidate instanceof class_1569 && candidate.method_5805());

        for (class_1309 hostile : hostiles) {
            class_243 toward = hostile.method_73189().method_1020(player.method_73189()).method_1029();
            // Negative dot product means it is behind them.
            if (facing.method_1026(toward) > -0.15) continue;

            double distance = hostile.method_5739(player);
            if (distance > 8.0) continue;

            mark(who, "danger", now);
            String what = hostile instanceof class_1548 ? "a creeper" : "a " + hostile.method_5864().method_5897().getString();
            return "[Something is happening: " + what + " is " + Math.round(distance)
                    + " blocks behind them and they have not seen it. Warn them, in a few words.]";
        }
        return null;
    }

    private static String badlyHurt(class_3222 player, UUID who, long now) {
        if (player.method_6032() > 6.0f) return null;
        if (!ready(who, "hurt", HURT_MS, now)) return null;

        mark(who, "hurt", now);
        return "[Something is happening: they are down to " + Math.round(player.method_6032())
                + " health. Say something about it — briefly, and without panicking.]";
    }

    /**
     * Something good in a wall they walked straight past.
     *
     * Only what is exposed and behind them, for the same reason as the mobs:
     * pointing at ore already on screen is noise.
     */
    private static String orePassed(class_3218 world, class_3222 player,
                                    UUID who, long now) {
        if (!ready(who, "ore", ORE_MS, now)) return null;

        class_2338 at = player.method_24515();
        for (int dx = -5; dx <= 5; dx++) {
            for (int dy = -4; dy <= 2; dy++) {
                for (int dz = -5; dz <= 5; dz++) {
                    class_2338 pos = at.method_10069(dx, dy, dz);
                    if (!WORTH_MENTIONING.contains(world.method_8320(pos).method_26204())) continue;

                    // Exposed to a space they could actually reach it from.
                    boolean open = false;
                    for (net.minecraft.class_2350 face : net.minecraft.class_2350.values()) {
                        if (world.method_8320(pos.method_10093(face)).method_26215()) {
                            open = true;
                            break;
                        }
                    }
                    if (!open) continue;

                    mark(who, "ore", now);
                    String name = world.method_8320(pos).method_26204().method_9518().getString();
                    return "[Something is happening: there is exposed " + name + " at "
                            + pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260()
                            + ", close by and they have not touched it. Point it out.]";
                }
            }
        }
        return null;
    }

    /** Night falling while they are out in the open with nothing lit. */
    private static String caughtOutside(class_3218 world, class_3222 player,
                                        UUID who, long now) {
        long time = world.method_8532() % 24000L;
        if (time < 12200 || time > 13600) return null;
        if (!world.method_8311(player.method_24515())) return null;
        if (world.method_8314(class_1944.field_9282, player.method_24515()) > 0) return null;
        if (!ready(who, "nightfall", NIGHTFALL_MS, now)) return null;

        mark(who, "nightfall", now);
        return "[Something is happening: the sun is going down and they are out in the open with "
                + "nothing lit nearby. Mention it.]";
    }

    /* --------------------------------------------------------- cooldowns */

    private static boolean ready(UUID who, String kind, long cooldown, long now) {
        Map<String, Long> theirs = SAID.get(who);
        if (theirs == null) return true;
        Long last = theirs.get(kind);
        return last == null || now - last >= cooldown;
    }

    private static void mark(UUID who, String kind, long now) {
        SAID.computeIfAbsent(who, id -> new ConcurrentHashMap<>()).put(kind, now);
        SAID.get(who).put("any", now);
    }

    private static long lastAnything(UUID who) {
        Map<String, Long> theirs = SAID.get(who);
        if (theirs == null) return 0L;
        return theirs.getOrDefault("any", 0L);
    }

    public static void forget(UUID who) {
        SAID.remove(who);
    }
}
