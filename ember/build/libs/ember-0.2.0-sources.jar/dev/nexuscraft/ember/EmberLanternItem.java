package dev.nexuscraft.ember;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * Calls Ember, sends it away, and tells it to stop lighting things.
 *
 * One item doing three jobs because a companion should not arrive with a
 * settings screen: right-click the air to call it or send it away, sneak and
 * right-click to tell it whether to keep placing torches.
 */
public class EmberLanternItem extends class_1792 {

    public EmberLanternItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 player, class_1268 hand) {
        if (!(world instanceof class_3218 serverWorld)) return class_1269.field_5812;

        EmberEntity existing = findOwned(serverWorld, player);

        if (player.method_5715()) {
            if (existing == null) {
                player.method_7353(class_2561.method_43471("item.ember.ember_lantern.none"), true);
                return class_1269.field_5812;
            }
            boolean lighting = existing.lightbringer().toggle();
            player.method_7353(class_2561.method_43471(lighting
                    ? "item.ember.ember_lantern.lighting_on"
                    : "item.ember.ember_lantern.lighting_off"), true);
            return class_1269.field_5812;
        }

        if (existing != null) {
            dismiss(serverWorld, existing, player);
            return class_1269.field_5812;
        }

        summon(serverWorld, player, player.method_73189().method_1031(0.0, 1.2, 0.0));
        return class_1269.field_5812;
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1657 player = context.method_8036();
        if (player == null) return class_1269.field_5811;
        return method_7836(context.method_8045(), player, context.method_20287());
    }

    private void summon(class_3218 world, class_1657 player, class_243 at) {
        EmberEntity ember = Ember.EMBER.method_5883(world, net.minecraft.class_3730.field_16471);
        if (ember == null) return;

        ember.method_5808(at.field_1352, at.field_1351, at.field_1350, player.method_36454(), 0.0f);
        ember.setOwner(player);
        world.method_8649(ember);

        world.method_65096(net.minecraft.class_2398.field_11240,
                at.field_1352, at.field_1351, at.field_1350, 24, 0.25, 0.25, 0.25, 0.03);
        world.method_8396(null, player.method_24515(), class_3417.field_17743,
                class_3419.field_15254, 0.8f, 1.3f);
        player.method_7353(class_2561.method_43471("item.ember.ember_lantern.summoned"), true);
    }

    private void dismiss(class_3218 world, EmberEntity ember, class_1657 player) {
        world.method_65096(net.minecraft.class_2398.field_11251,
                ember.method_23317(), ember.method_23318() + 0.2, ember.method_23321(), 18, 0.2, 0.2, 0.2, 0.02);
        world.method_8396(null, ember.method_24515(), class_3417.field_15102,
                class_3419.field_15254, 0.5f, 1.4f);
        /*
         * Whatever it was carrying goes back to the player.
         *
         * The satchel lives on the entity, so dismissing it without this would
         * quietly delete everything they had trusted it with — the worst thing
         * a container can do, and completely silent.
         */
        int returned = 0;
        var carried = ember.satchel();
        for (int slot = 0; slot < carried.method_5439(); slot++) {
            class_1799 held = carried.method_5438(slot);
            if (held.method_7960()) continue;
            returned += held.method_7947();
            if (!player.method_31548().method_7394(held)) player.method_7328(held, false);
        }
        carried.method_5448();

        if (returned > 0) {
            player.method_7353(class_2561.method_43470("Ember hands back " + returned + " items it was carrying.")
                    .method_27692(net.minecraft.class_124.field_1080), false);
        }

        ember.method_31472();
        player.method_7353(class_2561.method_43471("item.ember.ember_lantern.dismissed"), true);
    }

    /** The player's own Ember, if one is loaded nearby. */
    private EmberEntity findOwned(class_3218 world, class_1657 player) {
        class_238 box = player.method_5829().method_1014(48.0);
        List<EmberEntity> found = world.method_8390(EmberEntity.class, box,
                candidate -> player.method_5667().equals(candidate.getOwnerId()));
        return found.isEmpty() ? null : found.get(0);
    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return true;
    }
}
