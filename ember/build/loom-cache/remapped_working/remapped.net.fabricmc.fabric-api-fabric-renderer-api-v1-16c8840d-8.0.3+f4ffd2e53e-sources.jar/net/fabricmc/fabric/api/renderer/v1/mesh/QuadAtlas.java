/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.renderer.v1.mesh;

import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.util.Identifier;
import org.jspecify.annotations.Nullable;

/**
 * An atlas texture that a {@link QuadView} uses.
 */
public enum QuadAtlas {
	BLOCK(SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE),
	ITEM(SpriteAtlasTexture.ITEMS_ATLAS_TEXTURE);

	private final Identifier textureId;

	QuadAtlas(Identifier textureId) {
		this.textureId = textureId;
	}

	/**
	 * {@return the quad atlas for the given atlas texture ID or null if no corresponding quad atlas exists}
	 */
	@Nullable
	public static QuadAtlas of(Identifier atlasTextureId) {
		if (atlasTextureId.equals(SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE)) {
			return BLOCK;
		} else if (atlasTextureId.equals(SpriteAtlasTexture.ITEMS_ATLAS_TEXTURE)) {
			return ITEM;
		} else {
			return null;
		}
	}

	/**
	 * {@return the atlas texture ID}
	 */
	public Identifier getTextureId() {
		return textureId;
	}
}
